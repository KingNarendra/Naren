module.exports = {
  tokens: "8361440192:AAG_3xMM_zPkBGW474snnhWL01Yf8iU-GjY",  // Ubah Jadi Token Bot Mu !!!
  owner: "7560407350", // Ubah Jadi Id Mu !!!
  port: "2001", // Ubah Jadi Port Panel Mu !!!
  ipvps: "https://angkasa.aissoffc.my.id" // Ubah Jadi Ip Vps Mu !!!
};