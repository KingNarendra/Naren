module.exports = {
  tokens: "8429555667:AAGzeMihXrvF1SbjJST-PSuKRgJy8ZEf6RU",  // Masukin Bot token kamu
  owners: "8404950016", // Masukin ID Telegram kamu
  port: "2256", // Masukin Port panel kamu 
  ipvps: "http://pterodactyl.jwxhost.site" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};