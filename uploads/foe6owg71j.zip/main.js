/*
© Copyright By AiiSigma
*/
const chalk = require('chalk');

const startServer = require('./index.js');

console.log(chalk.green('🚀 Indictive Core starting...'));