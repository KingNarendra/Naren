export interface Endpoint {
  id: string;
  name: string;
  method: 'GET' | 'POST';
  path: string;
  description: string;
  params?: { name: string; type: string; required: boolean }[];
}

export interface Category {
  id: string;
  name: string;
  description: string;
  endpointCount: number;
  icon: string;
  endpoints: Endpoint[];
}

export const categories: Category[] = [
  {
    id: 'ai',
    name: 'Ai Interface',
    description: 'Collection of AI-related endpoints',
    endpointCount: 6,
    icon: 'Bot',
    endpoints: [
      { id: 'groq', name: 'Groq AI', method: 'GET', path: '/ai/groq', description: 'AI conversation with Groq', params: [{ name: 'text', type: 'string', required: true }] },
      { id: 'copilot', name: 'Copilot AI', method: 'GET', path: '/ai/copilot', description: 'AI conversation with Copilot', params: [{ name: 'text', type: 'string', required: true }] },
      { id: 'deepseek', name: 'DeepSeek AI', method: 'GET', path: '/ai/deepseek', description: 'AI conversation with DeepSeek', params: [{ name: 'text', type: 'string', required: true }] },
      { id: 'gpt4o', name: 'GPT-4o', method: 'GET', path: '/ai/gpt4o', description: 'AI conversation with GPT-4o', params: [{ name: 'text', type: 'string', required: true }] },
      { id: 'felo', name: 'Felo AI', method: 'GET', path: '/ai/felo', description: 'AI search with Felo', params: [{ name: 'text', type: 'string', required: true }] },
      { id: 'perplexity', name: 'Perplexity AI', method: 'GET', path: '/ai/perplexity', description: 'AI search with Perplexity', params: [{ name: 'text', type: 'string', required: true }] },
    ],
  },
  {
    id: 'tools',
    name: 'Tools',
    description: 'Collection of utility endpoints',
    endpointCount: 14,
    icon: 'Wrench',
    endpoints: [
      { id: 'ocr', name: 'Image OCR Reader', method: 'POST', path: '/tools/ocr', description: 'Extract text from image using OCR', params: [{ name: 'image', type: 'file', required: true }] },
      { id: 'veo3', name: 'VEO3 Video Generator', method: 'POST', path: '/tools/veo3', description: 'Generate video with AI from image and prompt', params: [{ name: 'image', type: 'file', required: true }, { name: 'prompt', type: 'string', required: true }] },
      { id: 'sdm', name: 'SDM Image Editor', method: 'POST', path: '/tools/sdm', description: 'Edit image with AI grayscale and red background', params: [{ name: 'image', type: 'file', required: true }] },
      { id: 'hijab', name: 'Hijab Generator', method: 'POST', path: '/tools/hijab', description: 'Convert hair to white hijab with AI', params: [{ name: 'image', type: 'file', required: true }] },
      { id: 'tts', name: 'Text to Speech', method: 'GET', path: '/tools/tts', description: 'Convert text to speech with multiple voices', params: [{ name: 'text', type: 'string', required: true }, { name: 'voice', type: 'string', required: false }] },
      { id: 'emojigif', name: 'Emoji to GIF', method: 'GET', path: '/tools/emojigif', description: 'Convert emoji to animated GIF', params: [{ name: 'emoji', type: 'string', required: true }] },
      { id: 'cuaca', name: 'Weather Info', method: 'GET', path: '/tools/cuaca', description: 'Get weather information for a city', params: [{ name: 'city', type: 'string', required: true }] },
      { id: 'pixel', name: 'Pixelate Image', method: 'POST', path: '/tools/pixel', description: 'Pixelate image effect', params: [{ name: 'image', type: 'file', required: true }] },
      { id: 'removebg', name: 'Remove Background', method: 'POST', path: '/tools/removebg', description: 'Remove background from image', params: [{ name: 'image', type: 'file', required: true }] },
      { id: 'iqc', name: 'iPhone Quote', method: 'GET', path: '/tools/iqc', description: 'Generate iPhone quote style', params: [{ name: 'text', type: 'string', required: true }] },
      { id: 'ssweb', name: 'Screenshot Website', method: 'GET', path: '/tools/ssweb', description: 'Take screenshot of website', params: [{ name: 'url', type: 'string', required: true }] },
      { id: 'qc', name: 'Quote Creator', method: 'GET', path: '/tools/qc', description: 'Create custom quote image', params: [{ name: 'text', type: 'string', required: true }, { name: 'author', type: 'string', required: false }] },
      { id: 'brat', name: 'Brat Generator', method: 'GET', path: '/tools/brat', description: 'Generate brat style text', params: [{ name: 'text', type: 'string', required: true }] },
      { id: 'ngl', name: 'NGL Message Sender', method: 'GET', path: '/tools/ngl', description: 'Send anonymous NGL message', params: [{ name: 'username', type: 'string', required: true }, { name: 'message', type: 'string', required: true }] },
    ],
  },
  {
    id: 'download',
    name: 'Download',
    description: 'Collection of download endpoints',
    endpointCount: 12,
    icon: 'Download',
    endpoints: [
      { id: 'github', name: 'GitHub Clone', method: 'GET', path: '/download/github', description: 'Clone GitHub repository as ZIP', params: [{ name: 'url', type: 'string', required: true }] },
      { id: 'anydown', name: 'AnyDown Universal Downloader', method: 'GET', path: '/download/anydown', description: 'Download from any supported platform', params: [{ name: 'url', type: 'string', required: true }] },
      { id: 'mediafire', name: 'MediaFire Download', method: 'GET', path: '/download/mediafire', description: 'Download files from MediaFire', params: [{ name: 'url', type: 'string', required: true }] },
      { id: 'spotify', name: 'Spotify Download', method: 'GET', path: '/download/spotify', description: 'Download music from Spotify', params: [{ name: 'url', type: 'string', required: true }] },
      { id: 'tiktok', name: 'TikTok Download', method: 'GET', path: '/download/tiktok', description: 'Download videos from TikTok', params: [{ name: 'url', type: 'string', required: true }] },
      { id: 'facebook', name: 'Facebook Download', method: 'GET', path: '/download/facebook', description: 'Download videos from Facebook', params: [{ name: 'url', type: 'string', required: true }] },
      { id: 'instagram', name: 'Instagram Download', method: 'GET', path: '/download/instagram', description: 'Download media from Instagram', params: [{ name: 'url', type: 'string', required: true }] },
      { id: 'ytmp3', name: 'YouTube MP3 Download', method: 'GET', path: '/download/ytmp3', description: 'Download YouTube as MP3', params: [{ name: 'url', type: 'string', required: true }] },
      { id: 'ytmp4', name: 'YouTube MP4 Download', method: 'GET', path: '/download/ytmp4', description: 'Download YouTube as MP4', params: [{ name: 'url', type: 'string', required: true }] },
      { id: 'xvideos', name: 'Xvideos Download', method: 'GET', path: '/download/xvideos', description: 'Download video from Xvideos', params: [{ name: 'url', type: 'string', required: true }] },
      { id: 'pornhub', name: 'PornHub Download', method: 'GET', path: '/download/pornhub', description: 'Download video from PornHub', params: [{ name: 'url', type: 'string', required: true }] },
      { id: 'xnxx', name: 'Xnxx Download', method: 'GET', path: '/download/xnxx', description: 'Download video from Xnxx', params: [{ name: 'url', type: 'string', required: true }] },
    ],
  },
  {
    id: 'search',
    name: 'Search',
    description: 'Collection of search endpoints',
    endpointCount: 12,
    icon: 'Search',
    endpoints: [
      { id: 'stickerly', name: 'Sticker Search', method: 'GET', path: '/search/stickerly', description: 'Search GIF stickers from Tenor', params: [{ name: 'query', type: 'string', required: true }] },
      { id: 'jadwaltv', name: 'TV Schedule', method: 'GET', path: '/search/jadwaltv', description: 'Get TV channel schedule', params: [{ name: 'channel', type: 'string', required: true }] },
      { id: 'gempa', name: 'Earthquake Info', method: 'GET', path: '/search/gempa', description: 'Get latest earthquake information from BMKG', params: [] },
      { id: 'spotify', name: 'Spotify Search', method: 'GET', path: '/search/spotify', description: 'Search music on Spotify', params: [{ name: 'query', type: 'string', required: true }] },
      { id: 'tiktok', name: 'TikTok Search', method: 'GET', path: '/search/tiktok', description: 'Search TikTok videos', params: [{ name: 'query', type: 'string', required: true }] },
      { id: 'groupsearch', name: 'WhatsApp Group Search', method: 'GET', path: '/search/groupsearch', description: 'Search WhatsApp groups', params: [{ name: 'query', type: 'string', required: true }] },
      { id: 'nik', name: 'NIK Search', method: 'GET', path: '/search/nik', description: 'Search NIK information', params: [{ name: 'nik', type: 'string', required: true }] },
      { id: 'youtube', name: 'YouTube Search', method: 'GET', path: '/search/youtube', description: 'Search YouTube content', params: [{ name: 'query', type: 'string', required: true }] },
      { id: 'pinterest', name: 'Pinterest Search', method: 'GET', path: '/search/pinterest', description: 'Search Pinterest content', params: [{ name: 'query', type: 'string', required: true }] },
      { id: 'xvideos', name: 'Xvideos Search', method: 'GET', path: '/search/xvideos', description: 'Search videos on Xvideos', params: [{ name: 'query', type: 'string', required: true }] },
      { id: 'pornhub', name: 'PornHub Search', method: 'GET', path: '/search/pornhub', description: 'Search videos on PornHub', params: [{ name: 'query', type: 'string', required: true }] },
      { id: 'xnxx', name: 'Xnxx Search', method: 'GET', path: '/search/xnxx', description: 'Search videos on Xnxx', params: [{ name: 'query', type: 'string', required: true }] },
    ],
  },
  {
    id: 'stalker',
    name: 'Stalker',
    description: 'Collection of social media stalking endpoints',
    endpointCount: 8,
    icon: 'UserSearch',
    endpoints: [
      { id: 'youtube', name: 'YouTube Stalk', method: 'GET', path: '/stalk/youtube', description: 'Get YouTube channel info and latest videos', params: [{ name: 'username', type: 'string', required: true }] },
      { id: 'twitter', name: 'Twitter Stalk', method: 'GET', path: '/stalk/twitter', description: 'Get Twitter user profile information', params: [{ name: 'username', type: 'string', required: true }] },
      { id: 'threads', name: 'Threads Stalk', method: 'GET', path: '/stalk/threads', description: 'Get Threads user profile information', params: [{ name: 'username', type: 'string', required: true }] },
      { id: 'tiktok', name: 'TikTok Stalk', method: 'GET', path: '/stalk/tiktok', description: 'Get TikTok user profile information', params: [{ name: 'username', type: 'string', required: true }] },
      { id: 'roblox', name: 'Roblox Stalk', method: 'GET', path: '/stalk/roblox', description: 'Get Roblox user complete information', params: [{ name: 'username', type: 'string', required: true }] },
      { id: 'instagram', name: 'Instagram Stalk', method: 'GET', path: '/stalk/instagram', description: 'Get Instagram user profile and posts', params: [{ name: 'username', type: 'string', required: true }] },
      { id: 'pinterest', name: 'Pinterest Stalk', method: 'GET', path: '/stalk/pinterest', description: 'Get Pinterest user profile information', params: [{ name: 'username', type: 'string', required: true }] },
      { id: 'github', name: 'GitHub Stalk', method: 'GET', path: '/stalk/github', description: 'Get GitHub user profile information', params: [{ name: 'username', type: 'string', required: true }] },
    ],
  },
  {
    id: 'random',
    name: 'Random',
    description: 'Collection of random content endpoints',
    endpointCount: 5,
    icon: 'Shuffle',
    endpoints: [
      { id: 'ba', name: 'Blue Archive', method: 'GET', path: '/random/ba', description: 'Get random Blue Archive character image', params: [] },
      { id: 'waifu', name: 'Waifu', method: 'GET', path: '/random/waifu', description: 'Get random waifu anime image', params: [] },
      { id: 'lahelu', name: 'Lahelu Random', method: 'GET', path: '/random/lahelu', description: 'Get random posts from Lahelu platform', params: [] },
      { id: 'neko', name: 'Random Neko', method: 'GET', path: '/random/neko', description: 'Get random anime neko image', params: [] },
      { id: 'nsw', name: 'Random NSW', method: 'GET', path: '/random/nsw', description: 'Get random NSW content', params: [] },
    ],
  },
  {
    id: 'create',
    name: 'Pterodactyl Create',
    description: 'Collection of Pterodactyl panel creation endpoints',
    endpointCount: 2,
    icon: 'Server',
    endpoints: [
      { id: 'panel', name: 'Create Server', method: 'GET', path: '/create/panel', description: 'Create Pterodactyl server', params: [{ name: 'name', type: 'string', required: true }, { name: 'egg', type: 'string', required: true }] },
      { id: 'admin', name: 'Create Admin', method: 'GET', path: '/create/admin', description: 'Create Pterodactyl admin', params: [{ name: 'email', type: 'string', required: true }, { name: 'password', type: 'string', required: true }] },
    ],
  },
];

export const appInfo = {
  title: 'Narendra-Api UI',
  name: 'Simple REST API',
  subtitle: 'Simple REST API by NarendraRajaIblis',
  version: 'v1.0.2',
  author: '@NarendraRajaIblis',
  baseUrl: 'https://piereeapi.vercel.app',
};
