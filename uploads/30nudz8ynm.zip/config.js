const fs = require("fs")

//===========================//

const {
smsg, getGroupAdmins, formatp, tanggal, formatDate, getTime, isUrl, await, sleep, clockString, msToDate, sort, toNumber, enumGetKey, runtime, fetchJson, getBuffer, jsonformat, delay, format, logic, generateProfilePicture, parseMention, getRandom, pickRandom, reSize
} = require("./system/lib/MyFunction")

//===========================//

global.d = new Date()
global.calender = d.toLocaleDateString("id")

//===========================//

global.prefa = ["","!",".",",","🎭","〽️"]
global.owner = ["6281313532320"]
global.ownMain = "6281313532320"
global.NamaOwner = "FyzzModss"
global.usePairingCode = true // Ubah Ke False Jika Ingin Menggunakan Qr Code
global.filenames = "message.js"
global.namabot = " ͠⤻𝐅𝐲𝐳𝐳 - 𝐂𝐫𝐚𝐬𝐡𝐞𝐫"
global.author = "r!🎭̻ !𝐅𝐲𝐳𝐳 𝐅𝐮*𝐜𝐤"
global.packname = "⭑̤⟅̊༑▾⿻⌜𝐓͢𝐡ͮ𝐞𝐂𝐫𝐚𝐬𝐡𝐞𝐝🐉⌟⿻▾༑̴⟆̊⭑"
global.yt = "https://youtube.com/@FyzzOffciall"
global.hiasan = `	◦  `
global.gris = '`'

global.mess = {
 ingroup: 'Can Only Used In Grup',
 admin: 'Can Only Be Used By Admin',
 owner: 'Can Only Be Used Owner',
 premium: 'Can Only Be Used Owner and Premium Used',
 usingsetpp: 'Settpp Only Be Used Owner',
 wait: 'Wait Proses Bree....',
 success: 'Successfully',
 bugrespon: 'Wait Bree....'
}

//===========================//

global.autOwn = 'req(62-8S57547ms11).287p'
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})