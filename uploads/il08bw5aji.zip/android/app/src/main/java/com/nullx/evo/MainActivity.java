package com.ravengetsuzo.id;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
