package com.nullx.evo;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
