module.exports = {
  tokens: "7986836613:AAHtJaAhJrqBOdH2hSrDwd5omt88Z1haBW0",  // Masukin Bot token kamu
  owners: "8398504165", // Masukin ID Telegram kamu
  port: "2021", // Masukin Port panel kamu 
  ipvps: "http://bakso pahina.my.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};