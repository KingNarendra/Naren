import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

// ════════════════════════════════════════════════════════════
//  GAME HUB — semua 4 mini-game dalam satu file
// ════════════════════════════════════════════════════════════

// ─── Color Palette (shared) ──────────────────────────────────
const Color _bg     = Color(0xFF0A0A12);
const Color _card   = Color(0xFF12121E);
const Color _border = Color(0xFF1E1E30);
const Color _green  = Color(0xFF39FF6E);
const Color _blue   = Color(0xFF00C8FF);
const Color _purple = Color(0xFF8B5CF6);
const Color _yellow = Color(0xFFFFD93D);
const Color _red    = Color(0xFFFF4444);
const Color _pink   = Color(0xFFFF6B9D);

// ════════════════════════════════════════════════════════════
//  GAME MENU PAGE
// ════════════════════════════════════════════════════════════
class GameMenuPage extends StatefulWidget {
  const GameMenuPage({super.key});
  @override
  State<GameMenuPage> createState() => _GameMenuPageState();
}

class _GameMenuPageState extends State<GameMenuPage>
    with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _entryCtrl;

  static const _games = [
    _GameCardData(
      title: 'Tebak Karakter\nFree Fire',
      subtitle: 'Kenali hero FF kamu!',
      emoji: '🔥',
      color: Color(0xFFFF6B35),
      accentColor: Color(0xFFFFD93D),
      route: 'ff',
    ),
    _GameCardData(
      title: 'Tebak\nGame',
      subtitle: 'Tebak game dari gambarnya',
      emoji: '🎮',
      color: Color(0xFF00C8FF),
      accentColor: Color(0xFF8B5CF6),
      route: 'game',
    ),
    _GameCardData(
      title: 'Tebak\nBendera',
      subtitle: 'Hafal bendera negara?',
      emoji: '🏳️',
      color: Color(0xFF39FF6E),
      accentColor: Color(0xFF00C8FF),
      route: 'flag',
    ),
    _GameCardData(
      title: 'Tebak Member\nJKT48',
      subtitle: 'Kenal siswi JKT48?',
      emoji: '🌸',
      color: Color(0xFFFF6B9D),
      accentColor: Color(0xFFFF9BD2),
      route: 'jkt',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat(reverse: true);
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entryCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _green, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: ShaderMask(
          shaderCallback: (b) =>
              const LinearGradient(colors: [_yellow, _pink]).createShader(b),
          child: const Text(
            'GAME ZONE',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
              fontSize: 20,
              letterSpacing: 2,
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          _buildBg(),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: _card,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                          color: _yellow.withValues(alpha: 0.3)),
                    ),
                    child: const Row(
                      children: [
                        Text('🎯', style: TextStyle(fontSize: 18)),
                        SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Pilih mini-game dan tantang temanmu!',
                            style: TextStyle(
                                color: Colors.white70, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: GridView.builder(
                      itemCount: _games.length,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 14,
                        mainAxisSpacing: 14,
                        childAspectRatio: 0.85,
                      ),
                      itemBuilder: (_, i) {
                        final g = _games[i];
                        return FadeTransition(
                          opacity: CurvedAnimation(
                            parent: _entryCtrl,
                            curve: Interval(i * 0.15, 0.6 + i * 0.1,
                                curve: Curves.easeOut),
                          ),
                          child: SlideTransition(
                            position: Tween<Offset>(
                              begin: const Offset(0, 0.4),
                              end: Offset.zero,
                            ).animate(CurvedAnimation(
                              parent: _entryCtrl,
                              curve: Interval(i * 0.15, 1.0,
                                  curve: Curves.easeOut),
                            )),
                            child: _buildGameCard(g),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBg() {
    return AnimatedBuilder(
      animation: _bgCtrl,
      builder: (_, __) => Stack(children: [
        Container(color: _bg),
        Positioned(
          top: -80, left: -80,
          child: Container(
            width: 260, height: 260,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  _yellow.withValues(alpha: 0.07 * _bgCtrl.value),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        Positioned(
          bottom: -60, right: -60,
          child: Container(
            width: 240, height: 240,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  _pink.withValues(alpha: 0.07 * (1 - _bgCtrl.value)),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildGameCard(_GameCardData g) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        Widget page;
        switch (g.route) {
          case 'ff':   page = const TebakFFPage();      break;
          case 'game': page = const TebakGamePage();    break;
          case 'flag': page = const TebakBenderaPage(); break;
          case 'jkt':  page = const TebakJKTPage();     break;
          default:     return;
        }
        Navigator.push(context, MaterialPageRoute(builder: (_) => page));
      },
      child: Container(
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: g.color.withValues(alpha: 0.4)),
          boxShadow: [
            BoxShadow(
              color: g.color.withValues(alpha: 0.12),
              blurRadius: 16,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 70, height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    g.color.withValues(alpha: 0.25),
                    g.color.withValues(alpha: 0.05),
                  ],
                ),
                border: Border.all(
                    color: g.color.withValues(alpha: 0.5), width: 1.5),
              ),
              child: Center(
                  child: Text(g.emoji,
                      style: const TextStyle(fontSize: 30))),
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: ShaderMask(
                shaderCallback: (b) =>
                    LinearGradient(colors: [g.color, g.accentColor])
                        .createShader(b),
                child: Text(
                  g.title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(
                g.subtitle,
                textAlign: TextAlign.center,
                style:
                    TextStyle(color: Colors.grey.shade600, fontSize: 10),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color: g.color.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: g.color.withValues(alpha: 0.4)),
              ),
              child: Text(
                'MAIN',
                style: TextStyle(
                  color: g.color,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GameCardData {
  final String title, subtitle, emoji, route;
  final Color color, accentColor;
  const _GameCardData({
    required this.title,
    required this.subtitle,
    required this.emoji,
    required this.color,
    required this.accentColor,
    required this.route,
  });
}

// ════════════════════════════════════════════════════════════
//  BASE STATE — shared logic untuk semua game
//  FIX: pakai abstract class State (bukan mixin) agar bisa
//  extends TickerProviderStateMixin tanpa konflik
// ════════════════════════════════════════════════════════════
abstract class _BaseTebakState<T extends StatefulWidget> extends State<T>
    with TickerProviderStateMixin {

  // ── Wajib di-override subclass ────────────────────────────
  String get apiUrl;
  String get pageTitle;
  String get pageEmoji;
  Color get themeColor;
  Color get accentColor;
  String extractImageUrl(Map<String, dynamic> data);
  String extractAnswer(Map<String, dynamic> data);

  // ── State ─────────────────────────────────────────────────
  bool isLoading = false;
  bool hasError  = false;
  String errorMsg = '';
  String? imageUrl;
  String? correctAnswer;
  bool? isCorrect;
  int score  = 0;
  int streak = 0;
  int round  = 0;
  bool revealed = false;

  final TextEditingController answerCtrl = TextEditingController();
  late AnimationController shakeCtrl;
  late Animation<double>    shakeAnim;
  late AnimationController  correctCtrl;
  late AnimationController  imgEntryCtrl;

  @override
  void initState() {
    super.initState();
    shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    shakeAnim = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: shakeCtrl, curve: Curves.elasticOut));
    correctCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    imgEntryCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    fetchQuestion();
  }

  @override
  void dispose() {
    shakeCtrl.dispose();
    correctCtrl.dispose();
    imgEntryCtrl.dispose();
    answerCtrl.dispose();
    super.dispose();
  }

  // ── Fetch soal ────────────────────────────────────────────
  Future<void> fetchQuestion() async {
    setState(() {
      isLoading     = true;
      hasError      = false;
      isCorrect     = null;
      revealed      = false;
      imageUrl      = null;
      correctAnswer = null;
      answerCtrl.clear();
    });
    imgEntryCtrl.reset();

    try {
      final res = await http
          .get(Uri.parse(apiUrl))
          .timeout(const Duration(seconds: 12));

      if (res.statusCode != 200) {
        throw Exception('Server error: HTTP ${res.statusCode}');
      }

      final json = jsonDecode(res.body) as Map<String, dynamic>;

      // Handle berbagai format response (termasuk tebakbendera yg wrap di 'detail')
      Map<String, dynamic>? data;
      if (json['data'] != null) {
        data = json['data'] as Map<String, dynamic>;
      } else if (json['detail'] != null) {
        final detail = json['detail'] as Map<String, dynamic>;
        if (detail['data'] != null) {
          data = detail['data'] as Map<String, dynamic>;
        }
      }

      if (data == null) throw Exception('Format response tidak dikenali');

      setState(() {
        imageUrl      = extractImageUrl(data!);
        correctAnswer = extractAnswer(data);
        isLoading     = false;
        round++;
      });
      imgEntryCtrl.forward();
    } catch (e) {
      setState(() {
        hasError  = true;
        errorMsg  = e.toString().replaceAll('Exception: ', '');
        isLoading = false;
      });
    }
  }

  // ── Cek jawaban ───────────────────────────────────────────
  void checkAnswer() {
    if (correctAnswer == null || answerCtrl.text.trim().isEmpty) return;
    final input  = answerCtrl.text.trim().toLowerCase();
    final answer = correctAnswer!.toLowerCase();
    final correct = input == answer ||
        answer.contains(input) ||
        input.contains(answer.split(' ').first);

    setState(() {
      isCorrect = correct;
      if (correct) {
        score += 10 + (streak * 5);
        streak++;
        correctCtrl.forward(from: 0);
      } else {
        streak = 0;
        shakeCtrl.forward(from: 0);
      }
    });
    HapticFeedback.mediumImpact();
  }

  void revealAnswer() {
    setState(() { revealed = true; isCorrect = false; streak = 0; });
  }

  // ── Build ─────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: themeColor, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Text(pageEmoji, style: const TextStyle(fontSize: 18)),
            const SizedBox(width: 8),
            Flexible(
              child: ShaderMask(
                shaderCallback: (b) =>
                    LinearGradient(colors: [themeColor, accentColor])
                        .createShader(b),
                child: Text(
                  pageTitle,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ),
          ],
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 14),
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: themeColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: themeColor.withValues(alpha: 0.4)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.star_rounded, color: _yellow, size: 14),
                const SizedBox(width: 4),
                Text(
                  '$score',
                  style: TextStyle(
                    color: themeColor,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: Column(
            children: [
              _buildStatsBar(),
              const SizedBox(height: 16),
              if (isLoading)
                _buildLoadingCard()
              else if (hasError)
                _buildErrorCard()
              else ...[
                _buildImageCard(),
                const SizedBox(height: 16),
                if (isCorrect != null) ...[
                  _buildFeedbackCard(),
                  const SizedBox(height: 14),
                ],
                if (revealed) ...[
                  _buildRevealCard(),
                  const SizedBox(height: 14),
                ],
                if (isCorrect == null && !revealed) ...[
                  _buildInputCard(),
                  const SizedBox(height: 10),
                  _buildHintButton(),
                ],
                if (isCorrect == true || revealed)
                  _buildNextButton(),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsBar() {
    return Row(
      children: [
        _statChip(Icons.loop_rounded, 'Ronde $round', _blue),
        const SizedBox(width: 8),
        _statChip(
          Icons.local_fire_department_rounded,
          streak > 0 ? 'Streak $streak 🔥' : 'Streak 0',
          streak > 0 ? _yellow : Colors.grey.shade700,
        ),
      ],
    );
  }

  Widget _statChip(IconData icon, String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 13),
          const SizedBox(width: 5),
          Text(label,
              style: TextStyle(
                  color: color,
                  fontSize: 11,
                  fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _buildLoadingCard() {
    return Container(
      height: 280,
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: themeColor.withValues(alpha: 0.2)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: themeColor, strokeWidth: 2),
          const SizedBox(height: 16),
          Text('Memuat soal...',
              style: TextStyle(
                  color: themeColor,
                  fontFamily: 'Orbitron',
                  fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildErrorCard() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: _red.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _red.withValues(alpha: 0.35)),
      ),
      child: Column(
        children: [
          const Icon(Icons.wifi_off_rounded, color: _red, size: 36),
          const SizedBox(height: 10),
          Text(errorMsg,
              textAlign: TextAlign.center,
              style:
                  const TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: _red.withValues(alpha: 0.2),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: fetchQuestion,
            icon: const Icon(Icons.refresh, size: 16),
            label: const Text('Coba Lagi'),
          ),
        ],
      ),
    );
  }

  Widget _buildImageCard() {
    return FadeTransition(
      opacity: imgEntryCtrl,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.08),
          end: Offset.zero,
        ).animate(CurvedAnimation(
            parent: imgEntryCtrl, curve: Curves.easeOut)),
        child: Container(
          width: double.infinity,
          constraints: const BoxConstraints(maxHeight: 340),
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(20),
            border:
                Border.all(color: themeColor.withValues(alpha: 0.4)),
            boxShadow: [
              BoxShadow(
                  color: themeColor.withValues(alpha: 0.1),
                  blurRadius: 20,
                  spreadRadius: 1),
            ],
          ),
          clipBehavior: Clip.antiAlias,
          child: imageUrl != null && imageUrl!.isNotEmpty
              ? Image.network(
                  imageUrl!,
                  fit: BoxFit.contain,
                  loadingBuilder: (ctx, child, progress) {
                    if (progress == null) return child;
                    return SizedBox(
                      height: 240,
                      child: Center(
                        child: CircularProgressIndicator(
                          color: themeColor,
                          strokeWidth: 2,
                          value: progress.expectedTotalBytes != null
                              ? progress.cumulativeBytesLoaded /
                                  progress.expectedTotalBytes!
                              : null,
                        ),
                      ),
                    );
                  },
                  errorBuilder: (_, __, ___) => SizedBox(
                    height: 200,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.broken_image_rounded,
                              color: Colors.grey.shade700, size: 48),
                          const SizedBox(height: 8),
                          Text('Gambar gagal dimuat',
                              style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                )
              : SizedBox(
                  height: 200,
                  child: Center(
                    child: CircularProgressIndicator(
                        color: themeColor, strokeWidth: 2),
                  ),
                ),
        ),
      ),
    );
  }

  Widget _buildFeedbackCard() {
    final correct = isCorrect == true;
    return AnimatedBuilder(
      animation: correct ? correctCtrl : shakeCtrl,
      builder: (_, __) {
        final shakeOffset = correct
            ? 0.0
            : (shakeAnim.value < 0.5
                    ? shakeAnim.value * 2
                    : (1 - shakeAnim.value) * 2) *
                6;
        return Transform.translate(
          offset: Offset(shakeOffset, 0),
          child: Container(
            width: double.infinity,
            padding:
                const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
            decoration: BoxDecoration(
              color: correct
                  ? _green.withValues(alpha: 0.1)
                  : _red.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: correct
                    ? _green.withValues(alpha: 0.5)
                    : _red.withValues(alpha: 0.5),
              ),
            ),
            child: Row(
              children: [
                Text(correct ? '🎉' : '❌',
                    style: const TextStyle(fontSize: 24)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        correct ? 'Jawaban Benar!' : 'Jawaban Salah!',
                        style: TextStyle(
                          color: correct ? _green : _red,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      if (correct) ...[
                        const SizedBox(height: 2),
                        Text(
                          '+${10 + (streak > 1 ? (streak - 1) * 5 : 0)} poin'
                          '${streak > 1 ? ' (streak bonus!)' : ''}',
                          style: const TextStyle(
                              color: _yellow, fontSize: 11),
                        ),
                      ],
                      if (!correct && correctAnswer != null) ...[
                        const SizedBox(height: 2),
                        Text(
                          'Jawaban: $correctAnswer',
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 11),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildRevealCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _yellow.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _yellow.withValues(alpha: 0.35)),
      ),
      child: Row(
        children: [
          const Text('💡', style: TextStyle(fontSize: 20)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Jawaban:',
                    style: TextStyle(
                        color: Colors.grey.shade500, fontSize: 11)),
                Text(
                  correctAnswer ?? '-',
                  style: const TextStyle(
                    color: _yellow,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputCard() {
    return Container(
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _border),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Jawaban kamu:',
              style: TextStyle(
                  color: Colors.grey.shade500, fontSize: 11)),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: _bg,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _border),
                  ),
                  child: TextField(
                    controller: answerCtrl,
                    style:
                        const TextStyle(color: Colors.white, fontSize: 15),
                    decoration: InputDecoration(
                      hintText: 'Ketik jawaban...',
                      hintStyle: TextStyle(
                          color: Colors.grey.shade700, fontSize: 13),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 12),
                    ),
                    textInputAction: TextInputAction.done,
                    onSubmitted: (_) => checkAnswer(),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: checkAnswer,
                child: Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    gradient:
                        LinearGradient(colors: [themeColor, accentColor]),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.send_rounded,
                      color: Colors.white, size: 22),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHintButton() {
    return TextButton.icon(
      onPressed: revealAnswer,
      icon: Icon(Icons.lightbulb_outline_rounded,
          color: Colors.grey.shade600, size: 16),
      label: Text('Lihat Jawaban',
          style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
    );
  }

  Widget _buildNextButton() {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient:
              LinearGradient(colors: [themeColor, accentColor]),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
                color: themeColor.withValues(alpha: 0.3),
                blurRadius: 12),
          ],
        ),
        child: ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14)),
          ),
          onPressed: fetchQuestion,
          icon: const Icon(Icons.skip_next_rounded,
              color: Colors.white, size: 22),
          label: const Text(
            'SOAL BERIKUTNYA',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
              fontSize: 13,
            ),
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
//  GAME 1: TEBAK KARAKTER FREE FIRE
// ════════════════════════════════════════════════════════════
class TebakFFPage extends StatefulWidget {
  const TebakFFPage({super.key});
  @override
  State<TebakFFPage> createState() => _TebakFFState();
}

class _TebakFFState extends _BaseTebakState<TebakFFPage> {
  @override
  String get apiUrl =>
      'https://api.fikmydomainsz.xyz/games/karakterfreefire';
  @override
  String get pageTitle => 'Karakter Free Fire';
  @override
  String get pageEmoji => '🔥';
  @override
  Color get themeColor => const Color(0xFFFF6B35);
  @override
  Color get accentColor => _yellow;
  @override
  String extractImageUrl(Map<String, dynamic> data) =>
      data['gambar'] ?? data['img'] ?? '';
  @override
  String extractAnswer(Map<String, dynamic> data) =>
      data['name'] ?? data['jawaban'] ?? '';
}

// ════════════════════════════════════════════════════════════
//  GAME 2: TEBAK GAME
// ════════════════════════════════════════════════════════════
class TebakGamePage extends StatefulWidget {
  const TebakGamePage({super.key});
  @override
  State<TebakGamePage> createState() => _TebakGameState();
}

class _TebakGameState extends _BaseTebakState<TebakGamePage> {
  @override
  String get apiUrl =>
      'https://api.fikmydomainsz.xyz/games/tebakgame';
  @override
  String get pageTitle => 'Tebak Game';
  @override
  String get pageEmoji => '🎮';
  @override
  Color get themeColor => _blue;
  @override
  Color get accentColor => _purple;
  @override
  String extractImageUrl(Map<String, dynamic> data) =>
      data['img'] ?? data['gambar'] ?? '';
  @override
  String extractAnswer(Map<String, dynamic> data) =>
      data['jawaban'] ?? data['name'] ?? '';
}

// ════════════════════════════════════════════════════════════
//  GAME 3: TEBAK BENDERA
// ════════════════════════════════════════════════════════════
class TebakBenderaPage extends StatefulWidget {
  const TebakBenderaPage({super.key});
  @override
  State<TebakBenderaPage> createState() => _TebakBenderaState();
}

class _TebakBenderaState extends _BaseTebakState<TebakBenderaPage> {
  @override
  String get apiUrl =>
      'https://api.fikmydomainsz.xyz/games/tebakbendera';
  @override
  String get pageTitle => 'Tebak Bendera';
  @override
  String get pageEmoji => '🏳️';
  @override
  Color get themeColor => _green;
  @override
  Color get accentColor => _blue;
  @override
  String extractImageUrl(Map<String, dynamic> data) =>
      data['img'] ?? data['gambar'] ?? '';
  @override
  String extractAnswer(Map<String, dynamic> data) =>
      data['name'] ?? data['jawaban'] ?? '';
}

// ════════════════════════════════════════════════════════════
//  GAME 4: TEBAK MEMBER JKT48
// ════════════════════════════════════════════════════════════
class TebakJKTPage extends StatefulWidget {
  const TebakJKTPage({super.key});
  @override
  State<TebakJKTPage> createState() => _TebakJKTState();
}

class _TebakJKTState extends _BaseTebakState<TebakJKTPage> {
  @override
  String get apiUrl =>
      'https://api.fikmydomainsz.xyz/games/tebakjkt';
  @override
  String get pageTitle => 'Tebak Member JKT48';
  @override
  String get pageEmoji => '🌸';
  @override
  Color get themeColor => _pink;
  @override
  Color get accentColor => const Color(0xFFFF9BD2);
  @override
  String extractImageUrl(Map<String, dynamic> data) =>
      data['gambar'] ?? data['img'] ?? '';
  @override
  String extractAnswer(Map<String, dynamic> data) =>
      data['jawaban'] ?? data['name'] ?? '';
}