import 'dart:async'; // Tambahan untuk Timer/Delay
import 'dart:convert';
import 'dart:ui'; // Diperlukan untuk efek blur (BackdropFilter)
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  // Callback update saldo (Dibiarkan ada agar tidak error di parent widget/Dashboard)
  final Function(double)? onCoinUpdated;
  final double currentCoin;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
    this.onCoinUpdated,
    this.currentCoin = 0,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  // Controllers
  final TextEditingController targetController = TextEditingController();
  late VideoPlayerController _videoController;
  
  // --- Controller untuk Video Processing ---
  late VideoPlayerController _processingVideoController;

  // --- NEW: Controller untuk Banner Video ---
  late VideoPlayerController _bannerVideoController;
  
  // Animation Controllers
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  // State Variables
  bool _isVideoInitialized = false;
  bool _isProcessingVideoInitialized = false; 
  bool _isBannerInitialized = false; // Status load banner
  String selectedBugId = "";
  bool _isSending = false;
  
  // --- Variable untuk Trigger Overlay Processing ---
  bool _showProcessingOverlay = false;

  // --- NEW: Variable untuk Mode Bug (Number / Group) ---
  bool _isGroupMode = false; // false = Number, true = Group

  // --- NEW: Variable untuk Tipe Sender (Private / VIP) ---
  bool _isVipSender = false; // false = Private (default), true = VIP Sender

  // --- PALETTE WARNA NEON ---
  final Color _neonPurple = const Color(0xFFD500F9); // Ungu Menyala
  final Color _neonPink = const Color(0xFFFF4081);   // Pink Menyala
  final Color _bgBlack = const Color(0xFF000000);    // Hitam Pekat
  final Color _vipGold = const Color(0xFFFFD700);    // Emas untuk VIP

  @override
  void initState() {
    super.initState();

    // Init Animation
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _fadeAnimation = CurvedAnimation(parent: _fadeController, curve: Curves.easeIn);
    _fadeController.forward();

    // Set default selected bug
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    // Init Video Background Utama
    _initializeVideoPlayer();
    
    // --- Init Video Processing ---
    _initializeProcessingVideo();

    // --- Init Banner Video ---
    _initializeBannerVideo();
  }

  void _initializeVideoPlayer() {
    // URL Video Background
    _videoController = VideoPlayerController.networkUrl(
      Uri.parse('https://i.top4top.io/m_36702w8j31.mp4'),
    )..initialize().then((_) {
        setState(() {
          _isVideoInitialized = true;
          _videoController.setVolume(1.0); 
          _videoController.setLooping(true);
          _videoController.play();
        });
      }).catchError((error) {
        debugPrint("Error initializing main video: $error");
      });
  }

  // --- Fungsi Load Video Processing ---
  void _initializeProcessingVideo() {
    _processingVideoController = VideoPlayerController.networkUrl(
      Uri.parse('https://g.top4top.io/m_3671ms73m1.mp4'), // Video Baru
    )..initialize().then((_) {
        setState(() {
          _isProcessingVideoInitialized = true;
          _processingVideoController.setLooping(true); // Loop agar tidak berhenti saat processing
        });
      }).catchError((error) {
        debugPrint("Error initializing processing video: $error");
      });
  }

  // --- Fungsi Load Banner Video (Asset) ---
  void _initializeBannerVideo() {
    _bannerVideoController = VideoPlayerController.asset(
      'assets/videos/banner.mp4', 
    )..initialize().then((_) {
        setState(() {
          _isBannerInitialized = true;
          _bannerVideoController.setLooping(true);
          _bannerVideoController.setVolume(0); // Banner biasanya mute
          _bannerVideoController.play();
        });
      }).catchError((error) {
        debugPrint("Error initializing banner video: $error");
      });
  }

  @override
  void dispose() {
    targetController.dispose();
    _videoController.dispose();
    _processingVideoController.dispose(); 
    _bannerVideoController.dispose(); // Dispose banner
    _fadeController.dispose();
    super.dispose();
  }

  // --- LOGIC DIRECT SEND (TANPA COIN) ---
  Future<void> _handleDirectSend() async {
    // 1. Validasi Input Awal
    final rawInput = targetController.text.trim();
    String? target;

    // --- NEW: LOGIC VALIDASI BERDASARKAN MODE ---
    if (_isGroupMode) {
      // Validasi Link Group
      if (rawInput.contains("chat.whatsapp.com")) {
        target = rawInput; // Gunakan link mentah
      } else {
        target = null;
      }
    } else {
      // Validasi Nomor (Existing)
      target = formatPhoneNumber(rawInput);
    }
    
    if (target == null) {
      _showNotification(
        "Invalid Input", 
        _isGroupMode ? "Masukkan Link Group WhatsApp yang valid!" : "Gunakan format internasional (cth: +628xxx)", 
        Colors.redAccent
      );
      return;
    }

    // --- BYPASS PEMBAYARAN: LANGSUNG KE ANIMASI & SEND ---
    
    // 2. Munculkan Overlay dan Play Video
    if (mounted) {
      setState(() {
        _isSending = true; // Set loading state button
        _showProcessingOverlay = true;
        _processingVideoController.seekTo(Duration.zero);
        _processingVideoController.play();
      });
    }

    // 3. Beri jeda waktu (simulasi proses) misal 4-5 detik agar video terlihat
    await Future.delayed(const Duration(seconds: 5));
    
    // 4. Panggil fungsi inti pengiriman bug (background)
    await _sendBug(target: target, skipLoadingSet: true); 

    // 5. Matikan Overlay
    if (mounted) {
      setState(() {
        _showProcessingOverlay = false;
        _processingVideoController.pause();
        _isSending = false; // Matikan loading button
      });
    }
  }

  // --- LOGIC PENGIRIMAN BUG ---
  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug({required String target, bool skipLoadingSet = false}) async {
    final key = widget.sessionKey;

    if (!skipLoadingSet) {
      setState(() {
        _isSending = true;
      });
    }

    try {
      // Encode target agar aman di URL (terutama untuk Link Group yang ada simbolnya)
      final encodedTarget = Uri.encodeComponent(target);
      
      // Base URL
      String url = "http://deatproject.storepanel.biz.id:3001/sendBug?key=$key&target=$encodedTarget&bug=$selectedBugId";
      
      // Tambahkan parameter type jika VIP Sender dipilih
      if (_isVipSender) {
        url += "&senderType=vip";
      } else {
        url += "&senderType=private";
      }
      
      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showNotification("⏳ Cooldown", "Harap tunggu beberapa saat sebelum mengirim lagi.", Colors.orange);
      } else if (data["valid"] == false) {
        _showNotification("❌ Invalid Key", "Sesi Anda tidak valid atau berakhir.", Colors.red);
      } else if (data["sended"] == false) {
        _showNotification("⚠️ Maintenance", "Server sedang dalam perbaikan.", Colors.redAccent);
      } else {
        String successMsg = _isGroupMode ? "Bug berhasil dikirim ke Group!" : "Bug berhasil dikirim ke $target!";
        if (_isVipSender) successMsg += " (VIP Sender)";
        
        _showNotification(
          "✅ Success", 
          successMsg, 
          _neonPurple
        );
        targetController.clear();
      }
    } catch (e) {
      _showNotification("❌ Error", "Gagal terhubung ke server.", Colors.red);
    } 
    // Finally tidak perlu matikan loading disini jika pakai overlay
    if (!skipLoadingSet) {
       setState(() => _isSending = false);
    }
  }

  void _showNotification(String title, String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        content: ClipRRect(
          borderRadius: BorderRadius.circular(15),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.8),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: color.withOpacity(0.8), width: 1.5),
                boxShadow: [
                  BoxShadow(color: color.withOpacity(0.2), blurRadius: 15, spreadRadius: 1)
                ]
              ),
              child: Row(
                children: [
                  Icon(
                    title.contains("Success") ? Icons.check_circle : Icons.info_outline,
                    color: color,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 16)),
                        Text(msg, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // --- UI BUILDER ---

  @override
  Widget build(BuildContext context) {
    // Cek Role
    final bool isVipUser = widget.role.toLowerCase() == 'vip' || widget.role.toLowerCase() == 'owner';

    return Scaffold(
      backgroundColor: _bgBlack, 
      resizeToAvoidBottomInset: false, 
      body: Stack(
        children: [
          // 1. BACKGROUND VIDEO UTAMA
          Positioned.fill(
            child: _isVideoInitialized
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoController.value.size.width,
                      height: _videoController.value.size.height,
                      child: VideoPlayer(_videoController),
                    ),
                  )
                : Container(color: _bgBlack),
          ),

          // 2. GRADIENT OVERLAY
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _bgBlack.withOpacity(0.3),
                    _bgBlack.withOpacity(0.8),
                    const Color(0xFF1A051A).withOpacity(0.9),
                  ]
                )
              ),
            ),
          ),

          // 3. MAIN CONTENT (Sekarang bisa di-scroll!)
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SingleChildScrollView( 
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 10),
                    // Header
                    _buildNeonHeader(),
                    
                    const SizedBox(height: 20),

                    // --- NEW: BANNER VIDEO WITH TEXT ---
                    Container(
                      height: 140, // Tinggi banner
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _neonPurple.withOpacity(0.4)),
                        boxShadow: [
                          BoxShadow(color: _neonPurple.withOpacity(0.1), blurRadius: 15, spreadRadius: 1)
                        ],
                        color: Colors.black,
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            // Layer 1: Video Banner
                            _isBannerInitialized
                                ? VideoPlayer(_bannerVideoController)
                                : const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)),
                            
                            // Layer 2: Overlay Darken (Supaya teks terbaca)
                            Container(color: Colors.black.withOpacity(0.3)),

                            // Layer 3: Text 𝕯𝖊𝖆𝖙𝖍 𝕲𝖍𝖔𝖘𝖙 V2
                            Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    "𝕯𝖊𝖆𝖙𝖍 𝕲𝖍𝖔𝖘𝖙 V2",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 28,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 3,
                                      fontFamily: 'Courier', // Atau font lain yang monospaced/cyberpunk
                                      shadows: [
                                        Shadow(color: _neonPurple, blurRadius: 15),
                                        const Shadow(color: Colors.black, blurRadius: 5, offset: Offset(2, 2)),
                                      ]
                                    ),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.only(top: 5),
                                    height: 2,
                                    width: 100,
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(colors: [Colors.transparent, _neonPink, Colors.transparent])
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 20),

                    // --- MODE TOGGLE BUTTONS (NUMBER / GROUP) ---
                    Container(
                      height: 45,
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.4),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: GestureDetector(
                              onTap: () => setState(() => _isGroupMode = false),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: !_isGroupMode ? _neonPurple.withOpacity(0.5) : Colors.transparent,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Center(
                                  child: Text(
                                    "Number Bug",
                                    style: TextStyle(
                                      color: !_isGroupMode ? Colors.white : Colors.grey,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: GestureDetector(
                              onTap: () => setState(() => _isGroupMode = true),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: _isGroupMode ? _neonPurple.withOpacity(0.5) : Colors.transparent,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Center(
                                  child: Text(
                                    "Bug Group",
                                    style: TextStyle(
                                      color: _isGroupMode ? Colors.white : Colors.grey,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 15),

                    // --- SENDER TOGGLE BUTTONS (PRIVATE / VIP) ---
                    // Hanya muncul jika user adalah VIP atau Owner
                    if (isVipUser) ...[
                      Container(
                        height: 45,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white12),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: GestureDetector(
                                onTap: () => setState(() => _isVipSender = false),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: !_isVipSender ? _neonPink.withOpacity(0.5) : Colors.transparent,
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.person, size: 16, color: !_isVipSender ? Colors.white : Colors.grey),
                                      const SizedBox(width: 8),
                                      Text(
                                        "Sender Private",
                                        style: TextStyle(
                                          color: !_isVipSender ? Colors.white : Colors.grey,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: GestureDetector(
                                onTap: () => setState(() => _isVipSender = true),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: _isVipSender ? _vipGold.withOpacity(0.5) : Colors.transparent,
                                    borderRadius: BorderRadius.circular(12),
                                    border: _isVipSender ? Border.all(color: _vipGold.withOpacity(0.5)) : null,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.diamond, size: 16, color: _isVipSender ? Colors.white : Colors.grey),
                                      const SizedBox(width: 8),
                                      Text(
                                        "Sender VIP",
                                        style: TextStyle(
                                          color: _isVipSender ? Colors.white : Colors.grey,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],

                    // Input Target
                    Text(
                      _isGroupMode ? "Target Group Link" : "Target Number", 
                      style: TextStyle(
                        color: _neonPink, 
                        fontWeight: FontWeight.bold, 
                        fontSize: 14,
                        shadows: [Shadow(color: _neonPink.withOpacity(0.5), blurRadius: 10)]
                      ),
                    ),
                    const SizedBox(height: 8),
                    _buildNeonInputContainer(
                      child: TextField(
                        controller: targetController,
                        style: const TextStyle(color: Colors.white, fontSize: 16),
                        keyboardType: _isGroupMode ? TextInputType.url : TextInputType.phone, 
                        decoration: InputDecoration(
                          hintText: _isGroupMode ? "https://chat.whatsapp.com/..." : "e.g. +62xxxxxxxxxx",
                          hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                          border: InputBorder.none,
                          prefixIcon: Icon(
                            _isGroupMode ? Icons.groups : Icons.call, 
                            color: _neonPurple, 
                            size: 20
                          ),
                          contentPadding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),

                    // Dropdown
                    Text(
                      "Bug Type",
                      style: TextStyle(
                        color: _neonPurple,
                        fontWeight: FontWeight.bold, 
                        fontSize: 14,
                        shadows: [Shadow(color: _neonPurple.withOpacity(0.5), blurRadius: 10)]
                      ),
                    ),
                    const SizedBox(height: 8),
                    _buildNeonInputContainer(
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedBugId,
                          dropdownColor: const Color(0xFF150515),
                          icon: Icon(Icons.keyboard_arrow_down, color: _neonPink),
                          isExpanded: true,
                          style: const TextStyle(color: Colors.white),
                          items: widget.listBug.map((bug) {
                            return DropdownMenuItem<String>(
                              value: bug['bug_id'],
                              child: Row(
                                children: [
                                  Icon(Icons.bug_report, size: 16, color: _neonPink),
                                  const SizedBox(width: 10),
                                  Text(bug['bug_name']),
                                ],
                              ),
                            );
                          }).toList(),
                          onChanged: (val) {
                            setState(() {
                              selectedBugId = val!;
                            });
                          },
                        ),
                      ),
                    ),

                    const SizedBox(height: 40),

                    // Menu Icons
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildMenuIcon(Icons.dns, "Server", _neonPurple),
                        _buildMenuIcon(Icons.security, "Security", Colors.white),
                        _buildMenuIcon(Icons.storage, "Database", _neonPink),
                      ],
                    ),

                    const SizedBox(height: 50), 

                    // Send Button Area
                    SizedBox(
                      height: 220, 
                      child: Stack(
                        alignment: Alignment.bottomCenter,
                        children: [
                          // Anime Character
                          Positioned(
                            bottom: 0,
                            left: 0,
                            child: Opacity(
                              opacity: 0.9,
                              child: Image.network(
                                'https://i.pinimg.com/originals/c9/22/68/c92268d92cf2dbf96e3195638d9214ce.png', 
                                height: 200,
                                fit: BoxFit.contain,
                                errorBuilder: (ctx, err, stack) => const SizedBox(),
                              ),
                            ),
                          ),
                            
                          // Send Button
                          Positioned(
                            bottom: 60,
                            left: 0,
                            right: 0,
                            child: GestureDetector(
                              // Mengubah handler ke _handleDirectSend (Tanpa Coin)
                              onTap: _isSending ? null : _handleDirectSend,
                              child: Container(
                                height: 55,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [_neonPurple.withOpacity(0.2), _neonPink.withOpacity(0.2)]
                                  ),
                                  borderRadius: BorderRadius.circular(30),
                                  border: Border.all(color: _neonPurple.withOpacity(0.8), width: 1.5),
                                  boxShadow: [
                                    BoxShadow(
                                      color: _neonPurple.withOpacity(0.3),
                                      blurRadius: 20,
                                      spreadRadius: 1,
                                    )
                                  ]
                                ),
                                child: Center(
                                  child: _isSending
                                    ? SizedBox(
                                        width: 24,
                                        height: 24,
                                        child: CircularProgressIndicator(color: _neonPink, strokeWidth: 2),
                                      )
                                    : Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.send, color: _neonPink, size: 24),
                                          const SizedBox(width: 10),
                                          Text(
                                            "SEND ATTACK",
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold,
                                              letterSpacing: 2,
                                              shadows: [
                                                Shadow(color: _neonPink, blurRadius: 15)
                                              ]
                                            ),
                                          ),
                                        ],
                                      ),
                                ),
                              ),
                            ),
                          ),
                          
                          // Disclaimer
                          Positioned(
                            bottom: 10,
                            child: Text(
                              "Use responsibly. We are not responsible for misuse.",
                              style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // 4. --- PROCESSING OVERLAY ---
          if (_showProcessingOverlay)
            Positioned.fill(
              child: Stack(
                children: [
                  // 4.1 Background Gelap Blur
                  BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
                    child: Container(
                      color: Colors.black.withOpacity(0.85),
                    ),
                  ),

                  // 4.2 Center Card Content
                  Center(
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.85,
                      padding: const EdgeInsets.all(2), // Space for Border
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        // Border Gradient Pink Neon
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [_neonPink, _neonPurple]
                        ),
                        boxShadow: [
                          BoxShadow(color: _neonPink.withOpacity(0.4), blurRadius: 20, spreadRadius: 2)
                        ]
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.black, // Inner Black
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Header Card
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
                              child: Column(
                                children: [
                                  Icon(Icons.send_rounded, color: _neonPink, size: 30),
                                  const SizedBox(height: 10),
                                  Text(
                                    "Sending FORCE CLOSE",
                                    style: TextStyle(
                                      color: Colors.white, 
                                      fontSize: 16, 
                                      fontFamily: 'Courier',
                                      fontWeight: FontWeight.bold
                                    ),
                                  ),
                                  const SizedBox(height: 5),
                                  Text(
                                    "to ${targetController.text}",
                                    style: TextStyle(
                                      color: _neonPink, 
                                      fontSize: 14,
                                      fontFamily: 'Courier',
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // Video Container
                            Container(
                              height: 200,
                              width: double.infinity,
                              color: Colors.black,
                              child: _isProcessingVideoInitialized
                                  ? ClipRect(
                                      child: FittedBox(
                                        fit: BoxFit.cover,
                                        child: SizedBox(
                                          width: _processingVideoController.value.size.width,
                                          height: _processingVideoController.value.size.height,
                                          child: VideoPlayer(_processingVideoController),
                                        ),
                                      ),
                                    )
                                  : const Center(child: CircularProgressIndicator()),
                            ),

                            // Footer Progress
                            Padding(
                              padding: const EdgeInsets.all(20),
                              child: Column(
                                children: [
                                  LinearProgressIndicator(
                                    backgroundColor: Colors.grey[900],
                                    color: _neonPink,
                                    minHeight: 6,
                                  ),
                                  const SizedBox(height: 15),
                                  Text(
                                    "Processing...",
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.7),
                                      letterSpacing: 2,
                                      fontSize: 12
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  // --- REUSABLE WIDGETS ---

  Widget _buildNeonHeader() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.4),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _neonPurple.withOpacity(0.5)),
            boxShadow: [
              BoxShadow(color: _neonPurple.withOpacity(0.1), blurRadius: 20)
            ]
          ),
          child: Row(
            children: [
              // Icon Profil
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [_neonPurple, _neonPink]),
                  shape: BoxShape.circle,
                  boxShadow: [
                      BoxShadow(color: _neonPink.withOpacity(0.6), blurRadius: 10)
                  ]
                ),
                child: const Icon(Icons.admin_panel_settings, color: Colors.white, size: 24),
              ),
              const SizedBox(width: 16),
              
              // Username & Role
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        shadows: [Shadow(color: Colors.purple, blurRadius: 5)]
                      ),
                    ),
                    Text(
                      widget.role.toUpperCase(),
                      style: TextStyle(
                        color: _neonPink,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        fontWeight: FontWeight.w600
                      ),
                    ),
                  ],
                ),
              ),

              // Expired Date Badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _neonPink.withOpacity(0.5)),
                  boxShadow: [BoxShadow(color: _neonPink.withOpacity(0.2), blurRadius: 5)]
                ),
                child: Text(
                  "EXP: ${widget.expiredDate}",
                  style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNeonInputContainer({required Widget child}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(15),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.3),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: _neonPurple.withOpacity(0.4)),
            boxShadow: [
              BoxShadow(color: _neonPurple.withOpacity(0.05), blurRadius: 10)
            ]
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _buildMenuIcon(IconData icon, String label, Color color) {
    return Column(
      children: [
        Container(
          width: 55,
          height: 55,
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.5),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withOpacity(0.6)),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.2), blurRadius: 10, spreadRadius: 0.5)
            ]
          ),
          child: Icon(icon, color: color, size: 26),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12),
        ),
      ],
    );
  }
}