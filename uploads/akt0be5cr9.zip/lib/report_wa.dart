//JANGAN LU MALING
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:ui'; // Untuk ImageFilter

class ReportWaPage extends StatefulWidget {
  final String sessionKey; // Pastikan ini ada
  final String role;       // Dan ini juga ada

  const ReportWaPage({
    super.key, 
    required this.sessionKey, 
    required this.role
  });

  @override
  State<ReportWaPage> createState() => _ReportWaPageState();
}


class _ReportWaPageState extends State<ReportWaPage> {
  // --- STYLE VARIABLES (Pink Aesthetic) ---
  // --- STYLE VARIABLES (Red Crimson Aesthetic) ---
final Color _primaryPink = const Color(0xFFE10600); // Crimson Red
final Color _softPink = const Color(0xFFFF3B30); // Bright Red Accent
final Color _bgTheme = const Color(0xFF0B0000); // Deep Dark Red Black
final Color _cardTheme = const Color(0xFF170000); // Dark Red Card
final Color _textWhite = Colors.white;
final Color _textGrey = const Color(0xFFB8A0A0); // Soft Grey Red Tint

  // --- CONTROLLERS ---
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  final ScrollController _logScrollController = ScrollController();

  // --- STATE VARIABLES ---
  bool _isAttacking = false;
  List<String> _logs = [];
  Timer? _attackTimer;

  @override
  void dispose() {
    _targetController.dispose();
    _amountController.dispose();
    _logScrollController.dispose();
    _attackTimer?.cancel();
    super.dispose();
  }

  // --- LOGIKA SIMULASI (TETAP UTUH) ---
  void _toggleAttack() {
    if (_isAttacking) {
      _stopAttack();
    } else {
      if (_targetController.text.isEmpty || _amountController.text.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: const Color(0xFFC2185B),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            content: const Text("Target & Amount cannot be empty!", style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        );
        return;
      }
      _startAttack();
    }
  }

  void _startAttack() {
    setState(() {
      _isAttacking = true;
      _logs.clear();
      _logs.add("[SYSTEM] Initializing Report Protocol...");
      _logs.add("[SYSTEM] Target: ${_targetController.text}");
      _logs.add("[SYSTEM] Connecting to WhatsApp Servers...");
    });

    // Simulasi Logs
    _attackTimer = Timer.periodic(const Duration(milliseconds: 200), (timer) {
      if (!mounted) return;

      final randomId = Random().nextInt(999999);
      final status = Random().nextBool() ? "SUCCESS" : "PENDING";
      
      setState(() {
        _logs.add("[PACKET-$randomId] Reporting ${_targetController.text} >> Status: $status");
        
        // Auto Scroll ke bawah
        if (_logScrollController.hasClients) {
          _logScrollController.jumpTo(_logScrollController.position.maxScrollExtent);
        }
      });

      // Stop otomatis jika logs terlalu banyak (hanya simulasi)
      if (_logs.length > 100) {
        _stopAttack();
      }
    });
  }

  void _stopAttack() {
    _attackTimer?.cancel();
    setState(() {
      _isAttacking = false;
      _logs.add("[SYSTEM] Process Finished or Stopped by User.");
      _logs.add("[SYSTEM] Disconnected.");
    });
  }

  // --- WIDGET BUILDER ---
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgTheme,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
  backgroundColor: Colors.transparent,
  elevation: 0,
  automaticallyImplyLeading: false, // Menghapus tombol kembali
  flexibleSpace: ClipRRect(
    child: BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
      child: Container(color: _bgTheme.withOpacity(0.5)),
    ),
  ),
),
      body: Container(
        decoration: BoxDecoration(
          // Background gradient halus pink
          gradient: RadialGradient(
            center: Alignment.topRight,
            radius: 1.5,
            colors: [_primaryPink.withOpacity(0.1), _bgTheme],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Column(
              children: [
                // 1. INPUT SECTION
                _buildInputCard(),

                const SizedBox(height: 20),

                // 2. ACTION BUTTON
                _buildActionButton(),

                const SizedBox(height: 20),

                // 3. TERMINAL LOGS (Dibuat lebih modern)
                Expanded(child: _buildTerminalLogs()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputCard() {
  return Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(32),
      gradient: LinearGradient(
        colors: [
          const Color(0xFF1A0000),
          const Color(0xFF120000),
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      border: Border.all(
        color: _primaryPink.withOpacity(0.25),
        width: 1.2,
      ),
      boxShadow: [
        BoxShadow(
          color: _primaryPink.withOpacity(0.15),
          blurRadius: 40,
          spreadRadius: 1,
          offset: const Offset(0, 15),
        ),
      ],
    ),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(32),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              /// HEADER PREMIUM
              Row(
                children: [
                  Container(
                    height: 52,
                    width: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          _primaryPink,
                          _softPink,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _primaryPink.withOpacity(0.6),
                          blurRadius: 20,
                          spreadRadius: 1,
                        )
                      ],
                    ),
                    child: const Icon(
                      FontAwesomeIcons.whatsapp,
                      color: Colors.white,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 18),

                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Target Configuration",
                        style: TextStyle(
                          color: _textWhite,
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.8,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Container(
                        height: 3,
                        width: 50,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          gradient: LinearGradient(
                            colors: [_primaryPink, _softPink],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 35),

              /// INPUT 1
              _buildElegantTextField(
                controller: _targetController,
                label: "Target Number",
                hint: "628xxxxxxxx",
                icon: Icons.phone_iphone_rounded,
                inputType: TextInputType.phone,
              ),

              const SizedBox(height: 22),

              /// INPUT 2
              _buildElegantTextField(
                controller: _amountController,
                label: "Report Amount",
                hint: "Enter amount",
                icon: Icons.confirmation_number_rounded,
                inputType: TextInputType.number,
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

  Widget _buildElegantTextField({
  required TextEditingController controller,
  required String label,
  required String hint,
  required IconData icon,
  required TextInputType inputType,
}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        label,
        style: TextStyle(
          color: _textGrey.withOpacity(0.8),
          fontSize: 13,
          fontWeight: FontWeight.w500,
        ),
      ),
      const SizedBox(height: 10),
      Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: const Color(0xFF0F0000),
          border: Border.all(
            color: _primaryPink.withOpacity(0.15),
          ),
        ),
        child: TextField(
          controller: controller,
          keyboardType: inputType,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
          cursorColor: _primaryPink,
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(
              color: _textGrey.withOpacity(0.4),
              fontSize: 13,
            ),
            prefixIcon: Icon(
              icon,
              color: _softPink,
              size: 20,
            ),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 20,
              vertical: 18,
            ),
          ),
        ),
      ),
    ],
  );
}

  Widget _buildActionButton() {
    return GestureDetector(
      onTap: _toggleAttack,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: _isAttacking ? const Color(0xFFFF5252) : _primaryPink,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: _isAttacking ? const Color(0xFFFF5252).withOpacity(0.4) : _primaryPink.withOpacity(0.4),
              blurRadius: 25,
spreadRadius: 1,
              offset: const Offset(0, 5),
            )
          ],
        ),
        child: Center(
          child: Text(
            _isAttacking ? "STOP ATTACK" : "START ATTACK",
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
        ),
      ),
    );
  }
  
  Widget _buildDot(Color color) {
  return Container(
    width: 10,
    height: 10,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: color,
    ),
  );
}

  Widget _buildTerminalLogs() {
  return Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(32),
      gradient: LinearGradient(
        colors: [
          const Color(0xFF140000),
          const Color(0xFF0F0000),
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      border: Border.all(
        color: _primaryPink.withOpacity(0.2),
        width: 1.2,
      ),
      boxShadow: [
        BoxShadow(
          color: _primaryPink.withOpacity(0.12),
          blurRadius: 40,
          spreadRadius: 1,
          offset: const Offset(0, 15),
        ),
      ],
    ),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(32),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
        child: Padding(
          padding: const EdgeInsets.all(26),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              /// HEADER SECTION (Premium Console Style)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      /// 3 Mac style dots
                      Row(
                        children: [
                          _buildDot(const Color(0xFFFF5F56)),
                          const SizedBox(width: 6),
                          _buildDot(const Color(0xFFFFBD2E)),
                          const SizedBox(width: 6),
                          _buildDot(const Color(0xFF27C93F)),
                        ],
                      ),
                      const SizedBox(width: 14),
                      Text(
                        "Activity Logs",
                        style: TextStyle(
                          color: _textWhite,
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                          letterSpacing: 0.6,
                        ),
                      ),
                    ],
                  ),

                  if (_isAttacking)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: _primaryPink.withOpacity(0.15),
                        border: Border.all(
                          color: _primaryPink.withOpacity(0.4),
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _softPink,
                              boxShadow: [
                                BoxShadow(
                                  color: _softPink.withOpacity(0.8),
                                  blurRadius: 10,
                                )
                              ],
                            ),
                          ),
                          const SizedBox(width: 6),
                          const Text(
                            "LIVE",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),

              const SizedBox(height: 25),

              /// LOG CONTAINER INNER
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: const Color(0xFF0B0000),
                    border: Border.all(
                      color: _primaryPink.withOpacity(0.1),
                    ),
                  ),
                  child: _logs.isEmpty
                      ? Center(
                          child: Text(
                            "System ready...",
                            style: TextStyle(
                              color: _textGrey.withOpacity(0.5),
                              fontSize: 13,
                            ),
                          ),
                        )
                      : ListView.builder(
                          controller: _logScrollController,
                          itemCount: _logs.length,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 5),
                              child: Text(
                                _logs[index],
                                style: TextStyle(
                                  color: _textWhite.withOpacity(0.9),
                                  fontSize: 12,
                                  height: 1.6,
                                  fontFamily: "monospace",
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
}