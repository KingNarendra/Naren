// ©AiiSigma

module.exports = {
  domain: "http://server-private.aiisigma.my.id",
  port: "3002"
};

// BOT TOKEN SAMA ID OWNER ADA DI index.js hal 26-27