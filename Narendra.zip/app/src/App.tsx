import { useState } from 'react';
import { 
  Bot, Wrench, Download, Search, UserSearch, Shuffle, Server, 
  ArrowLeft, Grid3X3, Terminal, Copy, Check, Play 
} from 'lucide-react';
import { categories, appInfo, type Category, type Endpoint } from './data/api-data';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';

type View = 'home' | 'category' | 'endpoint';

const iconMap: Record<string, React.ElementType> = {
  Bot,
  Wrench,
  Download,
  Search,
  UserSearch,
  Shuffle,
  Server,
};

function App() {
  const [currentView, setCurrentView] = useState<View>('home');
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [selectedEndpoint, setSelectedEndpoint] = useState<Endpoint | null>(null);
  const [paramValues, setParamValues] = useState<Record<string, string>>({});
  const [response, setResponse] = useState<string>('{"status": "waiting..."}');
  const [copied, setCopied] = useState(false);

  const handleCategoryClick = (category: Category) => {
    setSelectedCategory(category);
    setCurrentView('category');
    setParamValues({});
    setResponse('{"status": "waiting..."}');
  };

  const handleEndpointClick = (endpoint: Endpoint) => {
    setSelectedEndpoint(endpoint);
    setCurrentView('endpoint');
    setParamValues({});
    setResponse('{"status": "waiting..."}');
  };

  const handleBack = () => {
    if (currentView === 'endpoint') {
      setCurrentView('category');
      setSelectedEndpoint(null);
    } else if (currentView === 'category') {
      setCurrentView('home');
      setSelectedCategory(null);
    }
    setParamValues({});
    setResponse('{"status": "waiting..."}');
  };

  const handleParamChange = (paramName: string, value: string) => {
    setParamValues(prev => ({ ...prev, [paramName]: value }));
  };

  const generateCurl = () => {
    if (!selectedEndpoint) return '';
    const params = selectedEndpoint.params || [];
    const queryParams = params
      .filter(p => paramValues[p.name])
      .map(p => `${p.name}=${encodeURIComponent(paramValues[p.name])}`)
      .join('&');
    const url = `${appInfo.baseUrl}${selectedEndpoint.path}${queryParams ? '?' + queryParams : ''}`;
    return `curl -X ${selectedEndpoint.method} "${url}"`;
  };

  const handleCopyCurl = () => {
    navigator.clipboard.writeText(generateCurl());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTest = () => {
    setResponse('{"status": "testing..."}');
    // Simulate API call
    setTimeout(() => {
      setResponse(JSON.stringify({
        status: 200,
        success: true,
        message: 'API endpoint is active',
        timestamp: new Date().toISOString(),
      }, null, 2));
    }, 1000);
  };

  const renderHome = () => (
    <div className="min-h-screen bg-[#fafafa] flex flex-col items-center py-8 px-4">
      {/* Hero Video */}
<div className="w-full max-w-[780px] mb-4">
  <video
    src="/video.mp4"
    autoPlay
    loop
    muted
    playsInline
    className="w-full h-auto rounded-lg shadow-sm"
  />
</div>


      {/* Title Card */}
      <Card className="w-full max-w-[780px] mb-4 bg-white border-0 shadow-sm">
        <CardContent className="p-6 text-center">
          <h1 className="text-2xl font-mono font-bold text-gray-900 mb-2">
            {appInfo.name}
          </h1>
          <p className="text-sm text-gray-500 font-mono mb-4">
            {appInfo.subtitle}
          </p>
          <Badge 
            variant="secondary" 
            className="bg-gray-900 text-white hover:bg-gray-800 font-mono text-xs px-3 py-1"
          >
            {appInfo.version}
          </Badge>
        </CardContent>
      </Card>

      {/* Categories Card */}
      <Card className="w-full max-w-[780px] bg-white border-0 shadow-sm">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-6">
            <Grid3X3 className="w-5 h-5 text-gray-700" />
            <h2 className="text-lg font-mono font-semibold text-gray-900">
              API Categories
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((category) => {
              const IconComponent = iconMap[category.icon] || Bot;
              return (
                <div
                  key={category.id}
                  onClick={() => handleCategoryClick(category)}
                  className="p-4 rounded-lg border border-gray-100 hover:border-gray-200 hover:shadow-md transition-all cursor-pointer bg-white"
                >
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-lg bg-gray-900 flex items-center justify-center">
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <span className="font-mono font-semibold text-gray-900">
                      {category.name}
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 font-mono mb-1">
                    {category.description}
                  </p>
                  <p className="text-xs text-gray-400 font-mono">
                    {category.endpointCount} endpoints
                  </p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Footer */}
      <div className="mt-8 text-center">
        <p className="text-sm text-gray-500 font-mono">
          Created by
        </p>
        <p className="text-sm font-mono font-semibold text-gray-900">
          {appInfo.author}
        </p>
      </div>
    </div>
  );

  const renderCategory = () => {
    if (!selectedCategory) return null;
    const IconComponent = iconMap[selectedCategory.icon] || Bot;

    return (
      <div className="min-h-screen bg-[#fafafa] flex flex-col items-center py-8 px-4">
        {/* Header */}
        <Card className="w-full max-w-[780px] mb-4 bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBack}
              className="mb-4 -ml-2 text-gray-600 hover:text-gray-900 font-mono"
            >
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-gray-900 flex items-center justify-center">
                <IconComponent className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-mono font-bold text-gray-900">
                  {selectedCategory.name}
                </h1>
                <p className="text-sm text-gray-500 font-mono">
                  {selectedCategory.description}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Endpoints List */}
        <Card className="w-full max-w-[780px] bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="space-y-3">
              {selectedCategory.endpoints.map((endpoint) => (
                <div
                  key={endpoint.id}
                  onClick={() => handleEndpointClick(endpoint)}
                  className="p-4 rounded-lg border border-gray-100 hover:border-gray-200 hover:shadow-md transition-all cursor-pointer bg-white"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-mono font-semibold text-gray-900">
                      {endpoint.name}
                    </h3>
                    <Badge 
                      variant={endpoint.method === 'GET' ? 'default' : 'secondary'}
                      className={`font-mono text-xs ${
                        endpoint.method === 'GET' 
                          ? 'bg-blue-500 hover:bg-blue-600' 
                          : 'bg-orange-500 hover:bg-orange-600 text-white'
                      }`}
                    >
                      {endpoint.method}
                    </Badge>
                  </div>
                  <code className="text-xs text-gray-500 font-mono block mb-1">
                    {endpoint.path}
                  </code>
                  <p className="text-xs text-gray-400 font-mono">
                    {endpoint.description}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500 font-mono">
            Created by
          </p>
          <p className="text-sm font-mono font-semibold text-gray-900">
            {appInfo.author}
          </p>
        </div>
      </div>
    );
  };

  const renderEndpoint = () => {
    if (!selectedEndpoint || !selectedCategory) return null;

    return (
      <div className="min-h-screen bg-[#fafafa] flex flex-col items-center py-8 px-4">
        {/* Header */}
        <Card className="w-full max-w-[780px] mb-4 bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBack}
              className="mb-4 -ml-2 text-gray-600 hover:text-gray-900 font-mono"
            >
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back
            </Button>
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-xl font-mono font-bold text-gray-900 mb-2">
                  {selectedEndpoint.name}
                </h1>
                <div className="flex items-center gap-3">
                  <Badge 
                    variant={selectedEndpoint.method === 'GET' ? 'default' : 'secondary'}
                    className={`font-mono text-xs ${
                      selectedEndpoint.method === 'GET' 
                        ? 'bg-blue-500 hover:bg-blue-600' 
                        : 'bg-orange-500 hover:bg-orange-600 text-white'
                    }`}
                  >
                    {selectedEndpoint.method}
                  </Badge>
                  <code className="text-sm text-gray-500 font-mono">
                    {selectedEndpoint.path}
                  </code>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Parameters & Test */}
        <Card className="w-full max-w-[780px] mb-4 bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            {selectedEndpoint.params && selectedEndpoint.params.length > 0 ? (
              <div className="space-y-4 mb-6">
                {selectedEndpoint.params.map((param) => (
                  <div key={param.name}>
                    <label className="text-sm font-mono text-gray-700 block mb-2">
                      {param.name}:
                      {!param.required && (
                        <span className="text-gray-400 text-xs ml-1">(optional)</span>
                      )}
                    </label>
                    <Input
                      type={param.type === 'file' ? 'file' : 'text'}
                      placeholder={`Enter ${param.name}...`}
                      value={paramValues[param.name] || ''}
                      onChange={(e) => handleParamChange(param.name, e.target.value)}
                      className="font-mono text-sm"
                    />
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-500 font-mono mb-6">
                No parameters required for this endpoint.
              </p>
            )}
            
            <Button
              onClick={handleTest}
              className="w-full bg-gray-900 hover:bg-gray-800 text-white font-mono"
            >
              <Play className="w-4 h-4 mr-2" />
              Test Now
            </Button>
          </CardContent>
        </Card>

        {/* Response */}
        <Card className="w-full max-w-[780px] mb-4 bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <h3 className="text-sm font-mono font-semibold text-gray-900 mb-4">
              Response
            </h3>
            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500 font-mono">-</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500 font-mono">-</span>
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-400 font-mono">response.json</span>
              </div>
              <pre className="text-xs font-mono text-gray-700 overflow-x-auto">
                {response}
              </pre>
            </div>
          </CardContent>
        </Card>

        {/* cURL */}
        <Card className="w-full max-w-[780px] mb-4 bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-gray-600" />
                <span className="text-sm font-mono font-semibold text-gray-900">cURL</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleCopyCurl}
                className="text-gray-600 hover:text-gray-900"
              >
                {copied ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
            <div className="bg-gray-900 rounded-lg p-4">
              <code className="text-xs font-mono text-green-400 block">
                {generateCurl()}
              </code>
            </div>
          </CardContent>
        </Card>

        {/* Status Codes */}
        <Card className="w-full max-w-[780px] bg-white border-0 shadow-sm">
          <CardContent className="p-6">
            <h3 className="text-sm font-mono font-semibold text-gray-900 mb-4">
              Status Codes
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-3 rounded-lg bg-gray-50">
                <Badge className="bg-green-500 text-white mb-2">200</Badge>
                <p className="text-xs text-gray-600 font-mono">Success</p>
              </div>
              <div className="text-center p-3 rounded-lg bg-gray-50">
                <Badge className="bg-yellow-500 text-white mb-2">400</Badge>
                <p className="text-xs text-gray-600 font-mono">Bad Request</p>
              </div>
              <div className="text-center p-3 rounded-lg bg-gray-50">
                <Badge className="bg-orange-500 text-white mb-2">404</Badge>
                <p className="text-xs text-gray-600 font-mono">Not Found</p>
              </div>
              <div className="text-center p-3 rounded-lg bg-gray-50">
                <Badge className="bg-red-500 text-white mb-2">500</Badge>
                <p className="text-xs text-gray-600 font-mono">Server Error</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500 font-mono">
            Created by
          </p>
          <p className="text-sm font-mono font-semibold text-gray-900">
            {appInfo.author}
          </p>
        </div>
      </div>
    );
  };

  return (
    <div className="font-sans">
      {currentView === 'home' && renderHome()}
      {currentView === 'category' && renderCategory()}
      {currentView === 'endpoint' && renderEndpoint()}
    </div>
  );
}

export default App;
